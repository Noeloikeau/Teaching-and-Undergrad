#include <stdio.h>
 main () {
    int x = 0;
    int i_hr, i_min, i_sec;
    int r_hr, r_min, r_sec;
    int o_hr, o_min, o_sec;
    int count_s = 0, count_m = 0, count_h = 0;
    printf("Enter the time: ");
    scanf(" %d%d%d", &i_hr, &i_min, &i_sec);

    r_hr = (i_hr+1);
    r_min = (i_min +35);
    r_sec = (i_sec +38);
    
    o_hr = (r_hr%24);
    o_min = (r_min%60);
    o_sec = (r_sec%60);
    
    while (o_sec < 38) {
        o_min+=count_s;
        ++count_s;
                        }
    while (o_min <= 35) {
        o_hr+=count_m;
        ++count_m;
                        } 
    while (o_hr < i_hr) {
        o_hr = (o_hr%24);
        ++count_h;
                        }
    printf("\n");
    printf("The new carryover time is %d %d %d \n", (o_hr), (o_min), (o_sec)); 
 } 
