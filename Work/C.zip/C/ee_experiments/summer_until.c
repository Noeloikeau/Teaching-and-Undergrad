#include <stdio.h>
#include <string.h>
void main() {
    float input, output;
    char *ptr1 = "stop";
    char* arr[0];
    arr[0] = ptr1;
    printf("This program will take any amount of distinct numbers you choose and sum them. To stop entering, simply type: 'stop' without quotes. \n");
    scanf("%f" "[%s]", &input, arr[0]); 
    while (input < strlen(arr[0])) {
        scanf("%f", &input);
        output += input; 
        if (input == strlen(arr[0])) {
    printf("You entered stop! The sum of each number is %f", output);
        }
        }
}
    
    