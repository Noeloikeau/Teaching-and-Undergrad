int int_pow(int base, int exponent);
int get_string_size(char str[]);
int adapter(char str[]);