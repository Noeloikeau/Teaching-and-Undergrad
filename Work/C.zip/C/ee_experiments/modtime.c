#include <stdio.h>
void main() {
    int x;
    int y;
    printf("Enter two numbers: \n");
    scanf("%d%d", &x, &y);
    while (y>0) {
        if (x>y) {
            printf("Put: Lose %d \n", (x-y));
            printf("Call: Gain %d \n", (x-y));
            y-=5;
        } else if (x<y) {
            printf("Put: Gain %d \n", (x-y));
            printf("Call: Lose %d \n", (x-y));
            y-=5;
        }
    }
}