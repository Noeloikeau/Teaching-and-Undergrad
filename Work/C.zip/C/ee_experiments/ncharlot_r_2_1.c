#include <stdio.h>
#include "ncharlot_r_2_1_helpers.h"
#include "ncharlot_r_2_1_helpers.c"
#define MAX_STRING_SIZE 10

int main () {
  char number[] = "1234567890";
  printf("%d\n", adapter(number));
  return 0;
}
