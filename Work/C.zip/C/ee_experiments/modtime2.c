#include <stdio.h>
void main () {
    char i_unit, o_unit;
    int temp, i_year, o_year, i_month, o_month, i_week, o_week, i_day, o_day, i_hr, o_hr, i_min, o_min, sec;
    //Let them choose a unit of time 
    //Let them choose a unit of time they wish to convert into
    //output conversion
printf("This program will take a unit of time, an amount, a conversion unit, and output the conversion. \n");
printf("Enter a unit of time (year, month, week, day, hr, min, sec): ");
scanf("%c", &i_unit);
printf("\n");
printf("Enter an integer time value: \n");
scanf("%d", &temp);
printf("Enter a unit of time to convert to (year, month, week, day, hr, min, sec): ");
scanf("%c", &o_unit);
switch (i_unit) {
    case 'year': 
    i_year=temp;
    break;
    case 'month': 
    i_month=temp;
    
    break;
    case 'week': 
    i_week=temp;
    i_day=i_week*7
    i_hr=i_day*24
    i_min=i_hr*60
    sec=i_min*60
    break;
    case 'day': 
    i_day=temp;
    i_hr=i_day*24
    i_min=i_hr*60
    sec=i_min*60
    break;
    case 'hr': 
    i_hr=temp;
    i_min=i_hr*60
    sec=i_min*60
    break;
    case 'min': 
    i_min=temp;
    sec=i_min*60
    break;
    case 'sec': 
    sec=temp;
    break;
    default: 
    break;
}

if (i_hr=temp) {
    
}




























switch (o_unit) {
    case i_unit: printf("%d", i_unit);
    break;
    case 'year': i_year=;
    break;
    case 'month': i_month=;
    break;
    case 'week': i_week=;
    break;
    case 'day': i_day=;
    break;
    case 'hr': i_hr=;
    break;
    case 'min': i_min=;
    break;
    case 'sec': sec=;
    break;
    default: 
    break;
}
