five four three --> five hundred forty-three

537 = 5*100 + 3*10 + 7*1

= 5*10^2 + 3*10^1 + 7*10^0
digit: 5,3,7
exponent: 2,1,0
counter: 1,2,3
3-1=2
3-2=1
3-3=0

int counter;
int value = 0;
int base = 10;
int total_number_of_places = get_string_size(str);
int array_offset = -1;

for (counter=1; counter <= total_number_of_places; counter++) {
    int digit;
    
    if (str[counter + array_offset] == '0') {
      digit = 0;
    }
    if (str[counter + array_offset] == '1') {
      digit = 1;
    }
    if (str[counter + array_offset] == '2') {
      digit = 2;
    }
    if (str[counter + array_offset] == '3') {
      digit = 3; // digit will be 3 for second iteration
    }
    if (str[counter + array_offset] == '4') {
      digit = 4;
    }
    if (str[counter + array_offset] == '5') {
      digit = 5; // digit will be 5 for first iteration
    }
    if (str[counter + array_offset] == '6') {
      digit = 6;
    }
    if (str[counter + array_offset] == '7') {
      digit = 7; //digit will be 7 for last iteration
    }
    if (str[counter + array_offset] == '8') {
      digit = 8;
    }
    if (str[counter + array_offset] == '9') {
      digit = 9;
    }
    
    int exponent = total_number_of_places - counter; //  implement 543 = 5*100 + 4*10 + 3*1
    value += digit * int_pow(base, exponent);        //  implement 543 = 5*100 + 4*10 + 3*1
}

return value;



    int digit;
    switch (str[counter + a_off]) {
    case 0: digit =0;
    break;
    case 1: digit=1;
    break;
    case 2: digit=2;
    break;
    case 3: digit=3;
    break;
    case 4: digit=4;
    break;
    case 5: digit=5;
    break;
    case 6: digit=6;
    break;
    case 7: digit=7;
    break;
    case 8: digit=8;
    break;
    case 9: digit=9;
    break;
    }
