// This program will read in the input one character at a time and form a float value
// from the individual characters. If a non-numeric character is entered, the program
// will quit.

#include <stdio.h>
#include <stdlib.h>

main()
{
    char c = '\n';
    char buffer[128];
    float f = 0;
    int index = 0;

    // At the end of each iteration of this loop, if the input was a valid float, 
    // the character c should have the value of the new line character. If it is 
    // anything else, it will end the loop and quit the program.
    while (c == '\n')
    {
        printf("Input something: ");
        
        index = 0;
        c = 0;
        
        // Loop until the end of the input or an invalid character is found
        while (c != '\n')
        {
            // Read the next character from input
            scanf("%c", &c);
            
            // Check if the next character is a number or period
            if ((c >= '0' && c <= '9') || c == '.')
            {
                // Add the character to the buffer
                buffer[index] = c;
                index++;
            }
            else
            {
                // Non numeric input, break out of this loop.
                // But first, set the last character in buffer to the null terminator to indicate the end of the string
                buffer[index] = 0;
                break;
            }
        }
        
        if (index > 0)
        {
            // Set the float value and print
            f = atof(buffer);
            printf("Float value entered: %f\n", f);
        }
        else
        {
            // Program is ending. 
            printf("Goodbye!\n");
        }
    }
}
