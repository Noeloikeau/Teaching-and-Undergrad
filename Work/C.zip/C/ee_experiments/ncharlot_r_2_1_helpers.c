int int_pow(int base, int exponent) {
  int i = 1;
  int result = 1;
  while(i<=exponent) {
    result *= base;
    i++;
  }
  return result;
}

int get_string_size(char str[]) {
  int number_of_places = 0;  
  while (str[number_of_places] != '\0') {
    number_of_places++;
  }
  return number_of_places;
}

int adapter(char str[]) {
    int counter;
    int value = 0;
    int base = 10;
    int total_number_of_places = get_string_size(str);
    int array_offset = -1;
    int digit;
for (counter=1; counter <= total_number_of_places; counter++) {
    if (str[counter + array_offset] == '0') {
      digit = 0;
    }
    if (str[counter + array_offset] == '1') {
      digit = 1;
    }
    if (str[counter + array_offset] == '2') {
      digit = 2;
    }
    if (str[counter + array_offset] == '3') {
      digit = 3; 
    }
    if (str[counter + array_offset] == '4') {
      digit = 4;
    }
    if (str[counter + array_offset] == '5') {
      digit = 5;
    }
    if (str[counter + array_offset] == '6') {
      digit = 6;
    }
    if (str[counter + array_offset] == '7') {
      digit = 7;
    }
    if (str[counter + array_offset] == '8') {
      digit = 8;
    }
    if (str[counter + array_offset] == '9') {
      digit = 9;
    }
    int exponent = total_number_of_places - counter; 
    value += digit * int_pow(base, exponent);        
    }
    return value;
}