// Jian Yong Cao

#include <stdio.h>

main ()  {
    
    int num;
    int count, count_2, count_3;
    
    count = 0 ;
    count_2 = 0 ;
    count_3 = 0;
    
    
    while (num != 999) {
    printf ("Please enter a number that you want to repeat: \n");
    scanf ("%d", &num);
        
        if (num >= 0 && num <= 10){
            
            while (count < num ){
            printf(" %d\n", num);    
            count++;
            
            }
            count = 0;
        }
        else if (num >= 11 && num <= 100){
            while (count_2 < 15)  {
            printf(" %d\n", num);
            count_2++;
            
            }
            count_2 = 0;
        }
        else if (num > 100 && num != 999) {
            while (count_3 < 20) {
            printf(" %d\n", num);
            count_3++;
            
            }
            count_3 = 0;
        }
        else if (num == 999) {
            printf("You have typed 999 to exit the program.\n");
        }
    
    }
  
}