//Orbital problem example, orbital frequency = 1:35:38// 
/* This is the output: 
Enter zenith time (2digits, 0 if <10) (hr min sec, EOF to quit): 10 17 00
Next zenith at 11:52:38
Next zenith at 13:28:16
Next zenith at 15:03:54
Enter zenith time (hr min sec, EOF to quit): */ 
//Try use a single scanf("%i %i %i", &hr, &min, &sec)
#include <stdio.h>
void main() {
    float zenith;
    float hr;
    float min;
    float hr_mask;
    float sec;
    float min_mask;
    

    
        printf("Enter zenith time [must input 2 digits for each category] (hr min sec, EOF to quit): \n"); 
        scanf("%lf", &zenith);
    hr = (zenith/10000);
    
    hr_mask = (zenith/10000);
    hr_mask = hr_mask*10000;
    
    min_mask = (zenith - hr_mask)/100;
    min_mask = min_mask * 100;
    
    min = ((zenith - hr_mask)/100);
    sec = zenith - hr_mask - min_mask;
        printf("Next zenith at %f %f %f \n", hr, min, sec);

}
    
    