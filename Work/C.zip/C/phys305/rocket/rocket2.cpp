using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI


main(int argc,char *argv[]){
    ofstream outfile; 
    outfile.open("rocket2.txt");
	outfile.precision(5);
   double A=(PI/4.0)*1.32*1.32;
   double p=26051.0;
   double m0=15592.0;
   double mf=13326.0;
   double t0=115.0;
   double C=0.25;
   double M=5.972*pow(10.0,24.0);
   double G=6.674*pow(10.0,-11.0);
   double R=6.371*pow(10.0,6.0);
   double g=9.81;
   double x,y,vx,vy,x0,y0,vx0,vy0,v,m,r,a,c,rc;
   double k1,k2;
   double X,Y,VX,VY,t,dt,T,rho,b;
   T = 10000.0;
   dt=0.01;
   x0=0.0;
   y0=0.0;
   vx0=5.0*cos(45.0*PI/180.0);
   vy0=5.0*sin(45.0*PI/180.0);
   m=m0;
   x=x0;
   y=y0;
   vx=vx0;
   vy=vy0;
   
   double T0=0.0;
   for(t=T0; t<T; t+=dt){
        m= t<=t0 ? m0-mf*t/t0 : m0-mf;
        c= t<=t0 ? p*g : 0.0;
        a=-G*M*m;
        rho=1.33/exp(y/8300.0);
        b=-0.5*A*0.25*rho;
        v=sqrt(vx*vx+vy*vy);
        r=sqrt(x*x+y*y+R*R+2.0*R*y);
        rc=pow(r,-3.0);
        k1=(1.0/m)*(a*x*rc+b*vx*v+sin(PI/2.0*t/t0)*c*vx/v); 
        double kx=k1;
        k2=(1.0/m)*(a*(y+R)*rc+b*vy*v+cos(PI/2.0*t/t0)*c*vy/v);
        double ky=k2;
        VX=vx+kx*dt;
        VY=vy+ky*dt;
        X=x+vx*dt;
        Y=y+vy*dt;
        x=X;
        y=Y;
        vx=VX;
        vy=VY;
        T= y>0 ? T : T0;
        //T= vy<11180.0 ? T : T0; //GmMR^-1=.5mv^2 -> v=sqrt(2GM/R)
        //T= y<12000000.0 ? T : T0;
        outfile << t << "  " << X << "  " << Y << endl;
		}

}
    