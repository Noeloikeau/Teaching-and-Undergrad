using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI


main(int argc,char *argv[]){
    ofstream outfile; 
    outfile.open("rocket.txt");
	outfile.precision(5);
   double A=(PI/4.0)*1.32*1.32;
   double p=26051.0;
   double m0=15592.0;
   double mf=13326.0;
   double t0=115.0;
   double C=0.25;
   double M=5.972*pow(10.0,24.0);
   //cout<<M<<endl;
   double G=6.674*pow(10.0,-11.0);
   double R=6.371*pow(10.0,6.0);
   double g=9.81;
   double x,y,vx,vy,x0,y0,vx0,vy0,v,m,r,a,c;
   double k1,k2;
   double X,Y,VX,VY,t,dt,T,rho,b;
   T = 10.0;
   dt=0.1;
   x0=1.0;
   y0=1.0;
   vx0=(p/m0)*cos(PI/4.0);
   //cout<<vx0<<endl;
   vy0=(p/m0)*sin(PI/4.0);
   //cout<<vy0<<endl;
   m=m0;
   x=x0;
   y=y0;
   vx=vx0;
   vy=vy0;
   k1=0.0;
   k2=0.0;
   rho=0.011311*exp(-0.034592*y);
    m= t<=t0 ? m0-mf*t/t0 : m0-mf;
    c= t<=t0 ? p*g : 0.0;
    a=-G*M*m;
    b=-0.5*A*0.25*rho;
    v=sqrt(vx*vx+vy*vy);
    r=sqrt(x*x+y*y)+R;
    double rc=pow(r,-3);
    //cout<<rc<<endl;
    k1=(1.0/m)*(a*x*rc+b*vx*v+c*vx/v);
cout<<k1<<endl;
   double T0=0.0;
   for(t=T0; t<T; t+=dt){
        k1=(1.0/m)*(a*x*rc+b*vx*v+c*vx/v);//(a*x/(pow(r,3.0))+b*v*vx+c*vx/v)/m;
        //cout<<k1<<endl;
        k2=(1.0/m)*(a*(R+y)*rc+b*vy*v+c*vy/v);
        VX=vx+k1*dt;
        //cout<<VX<<endl;
        VY=vy+k2*dt;
        //cout<<VY<<endl;
        X=x+vx*dt;
        Y=y+vy*dt;
        x=X;
        y=Y;
        vx=VX;
        vy=VY;
        m= t<=t0 ? m0-mf*t/t0 : m0-mf;
        //cout<<m<<endl;
        c= t<=t0 ? p*g : 0.0;
        //cout<<c<<endl;
        a=-G*M*m;
        //cout<<a<<endl;
        rho=0.0113*exp(-0.0346*y);
        //cout<<rho<<endl;
        b=-0.5*A*0.25*rho;
        //cout<<b<<endl;
        v=sqrt(vx*vx+vy*vy);
        //cout<<v<<endl;
        r=sqrt(x*x+y*y+R*R+2.0*R*y);
        //cout<<r<<endl;
        //cout<<pow(r,-3)<<endl;
        rc=pow(r,-3);
        //cout<<k2<<endl;
        outfile << t << "  " << X << "  " << Y << endl;
		//<< "  "<< VX << "  " << VY << endl; 
		}

}
    