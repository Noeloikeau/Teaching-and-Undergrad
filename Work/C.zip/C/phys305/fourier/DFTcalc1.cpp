/* Discrete Fourier transform, time to frequency domain*/
// P. Gorham, for physics 305
//  g++ DFTcalc.cpp DFT.cpp -o DFTcalc


using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include <complex>
#include "DFT.cpp"


#define PI M_PI   /* from values.h */
#define TWOPI (2.00000000000*PI)
#define ND 100001
#define NMAX 150000

typedef complex<double> dcmplx;  // define a shorthand for double complex

extern dcmplx dft(double*,double*,int,double);


main(int argc, char *argv[])
{
	ifstream infile;
	infile.open("pulsar.dat");
	ofstream outfile;
	outfile.open("fpulse.txt");
	double t[NMAX], f_t[NMAX];
	double fmin,fmax,fstep,nu,deltat,tau,Norm,A,y;
	int i;
	dcmplx Fnu;

	fmin  = 20.0;  // min frequency HZ
	fmax  = 350.0;  // max frequency HZ
	fstep = 0.1;
	y=0.0; //transformation variable used to subtract off average from signal
	i=0;
	for(i=0;i<ND;i++){
		infile >> t[i] >> f_t[i];
		y+=f_t[i]; //sum 
		}
		y=y/ND; //avg
	for(i=0;i<ND;i++){
		f_t[i]=f_t[i]-y; //subtract avg
		}
		infile.close();
		deltat = t[1]-t[0];
		tau = t[ND-1]-t[0];
		//cout<<deltat<<"\t"<<tau<<endl;
		Norm = 2.0/tau*sqrt(TWOPI);  //normalization to get amplitude
	for(nu=fmin;nu<fmax;nu+=fstep){
		Fnu = dft(t,f_t,ND,nu);
		A = Norm*sqrt(Fnu.real()*Fnu.real()+Fnu.imag()*Fnu.imag());
		A = A*A;
		A = log10(A);
		outfile<<nu<<"\t"<<Fnu.real()*Norm<<"\t"<<Fnu.imag()*Norm<<"\t"<<A<<endl;
		}

}