using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include <complex>
#include "DFT.cpp"
#define PI M_PI   /* from values.h */
#define TWOPI (2.00000000000*PI)
#define ND 148282
#define NMAX 150000
main(void){
	ifstream infile;
	infile.open("Crab.dat");
	ofstream outfile;
	outfile.open("lightcrab.txt");
	double t[NMAX], f_t[NMAX], c[NMAX], g[NMAX];
	double y,p,F,T;
	int i,j,N,K;
	K = 33; //should be multiples of true period. need to fix this to fix lightcurve
	F = 30.2452;
	T = 1.0/F;
	cout<<T<<endl;
	N = 302; //floor(10.0/(33.11e-3)) = integer number of cycles in time sample
	for(i=0;i<ND;i++){
		infile >> t[i] >> f_t[i];
		/*p=t[i]/T-floor(t[i]/T);
		p=p*((double)K);
		j=(int)p;
		g[j]++;
		c[j]+= t[i]/T < (double)N ? f_t[i]/g[j] : 0.0;*/
		
		
		p = TWOPI*t[i]*F;
		p = p - floor(p);
		p = p*180.0/PI;
		//cout<<floor(p)<<"\t"<<p<<endl;
		p = (int)(p/6.0000);
		j = (int)p;
		
		g[j]++;
		//c[j]+= t[i]/T < (double)N ? f_t[i]/g[j] : 0.0;
		c[j]+=f_t[i]/g[j];
		//c[(int)p]+=f_t[i];//491.684);
		}
	    infile.close();
	    for(j=0;j<70;j++){
	    	outfile<<j<<"\t"<<c[j]<<endl;
	    }
}