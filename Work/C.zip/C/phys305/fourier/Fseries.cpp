/*  fourier series approximations to some simple signals */
// g++ Fseries.cpp -o ~/bin/Fseries

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define PI M_PI
#define TMAX  1.0

main(int argc, char *argv[]){
	ofstream outfile; 
    outfile.open("saw.txt");
	
	double dt,fs,a[50],b[50],t,told,Ast,Astold,Aft,Aftold,w,a0;
	int Ncoeff,i,n,smod,start,cont;



	Ncoeff = 10;    // number of coefficients to use

	dt = 2.5e-3;               // 2.5 ms time step
	fs = 5.0;                  // 5 Hz frequency
	
a0 = 1.0;

	
	fprintf(stderr,"Input dc value a0:\n");
	  fscanf(stdin,"%lf", &a0);
  	fprintf(stderr,"Input %d cosine coefficients:\n",Ncoeff);
	  for(i=0;i<Ncoeff;i++)fscanf(stdin,"%lf", a+i);
  	fprintf(stderr,"Input %d sine coefficients:\n",Ncoeff);	
	  for(i=0;i<Ncoeff;i++)fscanf(stdin,"%lf", b+i);

	  

	t = dt; told = 0.0; Astold = 0.0; Aftold = 0.0;
	start = 1;

		
	  for(t=dt;t<TMAX;t += dt){
	
		// create the half sine wave of frequency fs

		w = 2.0*PI*fs;   // the angular frequency
		Ast = t - floor(t);  
		

	   // the Fourier series is a sum of cos & sin harmonics
           //----------here is the series sum-----------
		Aft = 0.0;
		for(n=1;n<=Ncoeff;n++){
			Aft +=  a[n-1]*cos(n*w*t) + b[n-1]*sin(n*w*t);
			}
			Aft += a0/2.;    // add the DC value
          //-------------------------------------------

		// write out the data
		fprintf(stdout,"%e %e %e\n",t, Ast, Aft);
		
		// these lines set the old values to the newer ones
		Astold = Ast;
		Aftold = Aft;
		told = t;
		start = 0;
	  }


	

}