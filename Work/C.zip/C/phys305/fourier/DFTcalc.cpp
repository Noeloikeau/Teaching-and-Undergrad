/* Discrete Fourier transform, time to frequency domain*/
// P. Gorham, for physics 305
//  g++ DFTcalc.cpp DFT.cpp -o DFTcalc


using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include <complex>
#include "DFT.cpp"


#define PI M_PI   /* from values.h */
#define TWOPI (2.00000000000*PI)
#define ND 120001
#define NMAX 150000

typedef complex<double> dcmplx;  // define a shorthand for double complex

extern dcmplx dft(double*,double*,int,double);


main(int argc, char *argv[])
{
	ifstream infile;
	infile.open("cellphone.dat");
	ofstream outfile;
	outfile.open("fphone.txt");
	double t[NMAX], f_t[NMAX];
	double fmin,fmax,fstep,nu,deltat,tau,Norm,A;
	int eof,nread,i;
	dcmplx Fnu;

	fmin  = 400.0e6;  // min frequency MHZ
	fmax  = 4000.0e6;  // max frequency MHZ
	fstep = 1.0e6;  // frequency step MHZ
	i=0;
	for(i=0;i<ND;i++){
		infile >> t[i] >> f_t[i];
		}
		infile.close();
		deltat = t[1]-t[0];
		tau = t[ND-1]-t[0];
	cout<<deltat<<"\t"<<tau<<endl;
	
		Norm = 2.0/tau*sqrt(TWOPI);  //normalization to get amplitude
	for(nu=fmin;nu<fmax;nu+=fstep){
		Fnu = dft(t,f_t,ND,nu);
		A = Norm*sqrt(Fnu.real()*Fnu.real()+Fnu.imag()*Fnu.imag());
		outfile<<nu<<"\t"<<Fnu.real()*Norm<<"\t"<<Fnu.imag()*Norm<<"\t"<<A<<endl;
		}
}