using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#define PI M_PI


main(int argc, char *argv[]){
    ofstream outfileR;
    ofstream outfileF1;
    ofstream outfileF3;
    ofstream outfileF5;
    ofstream outfileF30;
    outfileR.open("rmsaw.txt");
    outfileF1.open("saw1.txt");
    outfileF3.open("saw3.txt");
    outfileF5.open("saw5.txt");
    outfileF30.open("saw30.txt");
    int N,n,m;
    double R,rms,r,A,w,f,y,t,dt,T,F,a0;
    T = 10.0;
    dt = 0.1;
    a0 = 1.0;
    A = 1.0;
    f = 2.0;
    w = 2.0*PI*f;
    for(N=1; N<=30; N++) {
    double a[N],b[N];
    for(t=0.0; t<=T; t+=dt) {
    y = A*(t/f - floor(t/f));
    F = 0.0;
    for(n=1;n<=N;n++) {
        a[n] = 0.0;
        b[n] = -1.0/(((double)n)*PI);
        F += a[n]*cos(n*PI*t) + b[n]*sin(n*PI*t);
    }   
    F += a0/2.0;
    /*m = N==1 || N==3 || N==5 || N==30 ? 1 : 0;
    while(m==1) {
    outfileF((char)N)<< t <<"\t"<< y <<"\t"<< F <<endl;
    }*/
    if(N==1) {
        outfileF1<< t <<"\t"<< y <<"\t"<< F <<endl;
    }
    if(N==3) {
        outfileF3<< t <<"\t"<< y <<"\t"<< F <<endl;
    }
    if(N==5) {
        outfileF5<< t <<"\t"<< y <<"\t"<< F <<endl;
    }
    if(N==30) {
        outfileF30<< t <<"\t"<< y <<"\t"<< F <<endl;
    }
    r = y - F;
    R += r*r;
    } 
    rms=sqrt(R*dt/T);
    outfileR << N << " " << rms << endl;
    R = 0.0;
    }
    
}