#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
using namespace std;

#define Tmax  50     // seconds for integration


main(int argc,char *argv[])

{
  double u1,u2,k,g,l,xt0,t0,vt0,w,vtii,xtii,t,dt,xti,vti, xtrue,vtrue, x2i, v2i, x2ii, v2ii;
   ofstream outfile;  
 
	outfile.open("pend.dat");
	outfile.precision(5);         // set the precision for output

	g = 9.81;                   // spring constant
	l = 1.0;                   // mass in kg
	k = -9.81;
	xt0 = 1.0;                 // initial position
	t0 = 0.0;                  // initial time
	vt0 = 0.0;                 // initial velocity
	dt = 0.001;		   // time interva1, 0.001=1ms is default

	xti = xt0;               // set & print out the initial conditions
	vti = vt0;
	x2i = xt0;  
	v2i = vt0;
	t = t0;

/* Here is the loop that propagates the motion:
	vtii is the velocity at the new time, vti the previous step time;
	xtii is the new position, xti the previous;
	after each step is calculated, the old is set
	to the new, and the cycle is repeated  */

	for(t=t0; t<Tmax; t+= dt){
	    vtii = vti + dt*k*sin(xti);
		xtii = xti + dt*vti;
		x2ii = x2i + dt*(v2i+k*sin(x2i)*dt/2.0);
		v2ii = v2i + dt*k*(sin(x2i)+sin(v2i*dt/2.0));
		xti = xtii;  
		vti = vtii;
		x2i = x2ii;  
		v2i = v2ii;
		u1 = 0.5*vti*vti + 9.81*(1-cos(xti));
		u2 = 0.5*v2i*v2i + 9.81*(1-cos(x2i));
		xtrue = xt0*cos(w*t);
		vtrue = vt0  + -w*sin(w*t);
		outfile << t << "  " << xtii << "  " << vtii << "  " << u1 << " " << x2ii << "  " << v2ii << " " << u2 << " " << xtrue << "  " << vtrue << endl;
	   }


}