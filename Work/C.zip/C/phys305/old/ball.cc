#include <iostream>
#include <iomanip>
#include <fstream>
#define _USE_MATH_DEFINES
#include <cmath>

using namespace std;

#define H0 1.0 
#define g 9.80665 
#define m 1.0 

float tbounce(float);
float ybounce(float);
float E=m*g*H0;
main() {
int k=0,n=0,Nmax;
float C,yterm=0,ysum=0,tterm=0,tsum=0;
cerr << "Enter coefficient of restoration:"<< endl;
cin >> C;
cerr <<"Enter maximum number of bounces:" << endl;
cin >> Nmax;
cout << "# n    t   tsum    E   y   ysum" <<endl;

cout <<setprecision(3)<<"  "<< n << " " << tterm << " " << tsum << " " << E << " " << yterm << " " << ysum << endl;
tterm=tbounce(E);
tsum+=tterm;
yterm=ybounce(E);
ysum+=yterm;
n++;
cout <<setprecision(3)<<" "<< n << " " << tterm << " " << tsum << " " << E << " " << yterm << " " << ysum << endl;
E *= C;
for(k=0;k<Nmax;k++){
    tterm=tbounce(E);
    tsum+=2.*tterm;
    yterm=ybounce(E);
    ysum+=2.*yterm;
    E *= C;
    n += 2;
    cout <<setprecision(3)<<"  "<< n << " " << tterm << " " << tsum << " " << E << " " << yterm << " " << ysum << endl;
                    }}

float tbounce(float Eb) 
{
    float t =  sqrt(2*E/(m*g*g)); 
    return(t);
}


float ybounce(float Eb)
{
    float y = E/(m*g); 
    return (y);
}