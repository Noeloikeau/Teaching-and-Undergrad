using namespace std;       
#include <iostream>       
#include <iomanip>   // this is required to use "setprecision" below
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath> 
#include <cstdlib> 
#define PI  M_PI
#define max 10000
#define seed 681111
main(){
   int N=11;
   double x[max][N],ntrials[N],r[max][N],s[max],u[max][N]; 
   double hits[N];
   double rsq=0.0;
   srand48(seed);                     
   for (int j=1; j<max; j++) {
      
      for (int i=1; i<N; i++){
         x[j][i] = (drand48()-0.5)*2.;
         r[j][i] = r[j][i-1]+(x[j][i])*(x[j][i]);
         if (r[j][i]<=1.0) {
            u[j][i]=1.0;
         } else {
            u[j][i]=0;
          
         }  
   } for (int i=1; i<N; i++) { 
         r[j][i]=0.0;
            }
         
   }     
   
     for (int i=1; i<N; i++) {
      for (int j=1; j<max; j++){
      s[i]+=u[j][i];  
      }
      double l=i;
double g=(l/2.0)+1.0; 
double ratiot=s[i]/(max-1)*pow(2,l);
double ratioa=pow(sqrt(PI),l)/tgamma(g);
cout << " " << i <<" "<< ratiot <<
	 		" "<<ratioa<<" "<<(ratiot-ratioa)/ratioa<<endl; 
      }}
/*cout << "# Dimensions:" << i <<", T:"<< ratiot <<
	 		", A:"<<ratioa<<" fractional error= "<<(ratiot-ratioa)<<endl; 
      }}/*
      for (int i=2; i<N; i++){
double l=i;
double g=(l/2.0)+1.0; 
double ratiot=s[i]/(max-1);
double ratioa=pow(sqrt(PI)/2.0,l)/tgamma(g);
cout << "# Dimensions:" << i <<", T:"<< ratiot <<
	 		", A:"<<ratioa<<endl; 
   }}   


         /*
         for (int k=2; k<=i; k++) {
         rsq+=(x[j][k])*(x[j][k]);
         }
         if (rsq<=1.0) {
	      hits[i]++;
         } 
         rsq=0.0;
      }
      */
   
   /*}
 
  
 }
  
  
  
  
  
  /* for (int i=2; i<N; i++){
double l=i;
double g=(l/2.0)+1.0; 
double ratiot=hits[i]/(max-1);
double ratioa=pow(sqrt(PI)/2.0,l)/tgamma(g);
cout << "# Dimensions:" << i <<", T:"<< ratiot <<
	 		", A:"<<ratioa<<endl;     
   }*/
//}