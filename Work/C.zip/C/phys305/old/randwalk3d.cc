using namespace std;       
#include <iostream> 
#include <iomanip>   
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>   
#include <cstdlib> 
                      
#define SQRT2 M_SQRT2  // use the cmath definition...
#define max 10000  // absolute maxumum number of steps!
int seed = 94180717;  // change the seed if you want different results!

main(int argc, char *argv[])
{
   int i, j, Jrand, Nmax=1000;
   double x, y, z, u, v, r[max+1], Ntrials=100.; // Ntrials is the number of paths to try 
   
   if(argc > 1) {
      seed = atoi(argv[1]);  // argv[1] since argv[0] contains the program name!
       cerr << "Using user seed= "<< seed <<endl;     
   }else{
      cerr << "Using default seed= "<< seed <<endl;
   }
   
   ofstream outfile, outpath; 
   outfile.open("walk3d.dat"); 
   outpath.open("walkpath3d.dat");
   outpath << "0 0.0 0.0 0.0" <<endl;
   
   srand48(seed);                       // seed the number generator 
   					// if the seed is the same the randoms
					//   will also be the same 			   
   Jrand =  (int)(drand48()*Ntrials); // pick one path to print out 
   
   for (i=0; i<=Nmax; i++) r[i]=0.0;     // clear array 
   
   for (j=1; j<=(int)Ntrials; j++){      // average over NTRIALS trials 
      x=y=z=0;                            // starting point  
      for (i=1; i<=Nmax; i++){
         u=drand48()*2.-1.;
         v=drand48()*2.*M_PI;
         x +=(sqrt(1.-u*u))*cos(v);      
         y +=(sqrt(1.-u*u))*sin(v) ;     
         z += u;
         r[i] += sqrt(x*x + y*y +z*z);           // 3D distance from origin 
	 
	 if(j==Jrand){  // print out a random trial path for plotting:
	 	outpath <<  i <<" "<< x <<" "<< y <<" "<< z <<endl;
	    }
		
      }
   }
   
   for (i=0; i<=Nmax; i++){		// write results into file, including standard error     
      outfile<< i << "  "<<r[i]/Ntrials << "  "<<sqrt(Ntrials)/Ntrials * r[i]/Ntrials << endl;
   }
   cerr << "data stored in walk3d.dat"<< endl;
   cerr << "path #"<<Jrand<<" stored in walkpath3d.dat"<<endl;
   outfile.close();
   outpath.close();
}