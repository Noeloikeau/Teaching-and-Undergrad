using namespace std;       
#include <iostream>       
#include <iomanip>   // this is required to use "setprecision" below
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>   
#define mat_in  2500                  /* mat number of dts */
#define vmin -6.0                       /* ranges of integration */
#define vmat 6.0			
#define ME M_E
float r=1.2; /*kg/m^3*/
float c=343.00; /*m/s*/
float a=20.00; /*pa*/
float w=1.00/216.00; /*hz*/
float trapez  (int no, float min, float mat);    /* trapezoid rule */
float simpson (int no, float min, float mat);    /* Simpson's rule */
float f(float);		        	/*  contains function to integrate */

main()
{		 
   float result; // declare this within scope of main
   ofstream myfile;  // declare a new instance of an output stream, call it "myfile"
   
 
   myfile.open("integ.dat");  // open is now a method within ofstream class instance outfile
   
   for (int i=3; i<=mat_in; i+=2){	   // Simpson's rule requires odd number of dts
      result = trapez(i, vmin, vmat);
      myfile<<"{" << w*i-6 <<"," <<"\t"<< setprecision(9) << result <<","<<"\t";  // "\t" here gives a tab
      result = simpson(i, vmin, vmat);
      myfile << setprecision(9) << result<<"}," << endl;
   }
   cout << "data stored in integ.dat" << endl;
   myfile.close();  // close the file, disable any more writing to it, button it up.
}
/*------------------------end of main program-------------------------*/

/* the function we want to integrate */
float f (float t)
{ 
 return pow(a*cos(pow(t,3.))*exp(-pow(t/4.,8.)),2)/(r*c);  // this function for chirp
//return (etp(-t));    // this is etponential
}

/* Integration using trapezoid rule */
float trapez (int no, float min, float mat)
{			
   float dt, sum=0., t;		 
   dt = w;
   sum += 0.5*f(min)*dt; 
   for (int n=2; n<no; n++)           
   {
      t = min + dt * (n-1);      
      sum += f(t)*dt;
   }
   sum += 0.5 *f(mat) * dt;
   return (sum);
}      

/* Integration using Simpson's rule */ 
float simpson (int no, float min, float mat)
{  				 
   float dt, sum=0., t;
   dt = w;
   for (int n=2; n<no; n+=2)              
   {
       t = min + dt * (n-1);
       sum += 4 * f(t);
   }
   for (int n=3; n<no; n+=2)              
   {
      t = min + dt * (n-1);
      sum += 2 * f(t);
   }   
   sum +=  f(min) + f(mat);	         
   sum *= dt/3.;        	
   return (sum);
}