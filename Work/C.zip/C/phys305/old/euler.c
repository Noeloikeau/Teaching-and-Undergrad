#include <stdio.h>
#include <math.h>
void main() {
unsigned int n = 0; // Iteration.  Start with n=0;
double fact = 1;    // 0! = 1.  Keep running product of iteration numbers for factorial.
double sum = 0;     // Starting summation.  Keep a running sum of terms.
double last;        // Sum of previous iteration for computing e
double e=0.1;           // epsilon value for deciding when done.

do {
    last = sum;
    sum += 1/fact;
    fact *= ++n;
} while(sum-last >= e);
  printf("The sum is %f \n", sum);
}