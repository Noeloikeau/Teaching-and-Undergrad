using namespace std;       
#include <iostream> 
#include <iomanip>   
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>   
#include <cstdlib> 
                      
#define SQRT2 M_SQRT2  // use the cmath definition...
#define max 10000  // absolute maxumum number of steps!
int seed = 94180717;  // change the seed if you want different results!

main(int argc, char *argv[])
{
   int i, j, Jrand, Nmax=1000;
   double x, y, r[max+1], Ntrials=100.; // Ntrials is the number of paths to try 
   
   if(argc > 1) {
      seed = atoi(argv[1]);  // argv[1] since argv[0] contains the program name!
       cerr << "Using user seed= "<< seed <<endl;     
   }else{
      cerr << "Using default seed= "<< seed <<endl;
   }
   
   ofstream outfile, outpath; 
   outfile.open("walk2d.dat"); 
   outpath.open("walkpath2d.dat");
   outpath << "0 0.0 0.0" <<endl;
   
   srand48(seed);                       // seed the number generator 
   					// if the seed is the same the randoms
					//   will also be the same 			   
   Jrand =  (int)(drand48()*Ntrials); // pick one path to print out 
   
   for (i=0; i<=Nmax; i++) r[i]=0.0;     // clear array 
   
   for (j=1; j<=(int)Ntrials; j++){      // average over NTRIALS trials 
      x=y=0;                            // starting point  
      for (i=1; i<=Nmax; i++){
         x += cos(drand48()*2.*M_PI);      // dx and dy using cosine and sine of
         y += sin(drand48()*2.*M_PI);      //    random angle bewteen 0, 2pi
         r[i] += sqrt(x*x + y*y);           // 2D distance from origin 
	 
	 /*if(j==Jrand){  // print out a random trial path for plotting:
	 	outpath <<  i <<" "<< x <<" "<< y <<endl;
	    }*/
            if(i==Nmax){  // print out a random trial path for plotting:
	 	         outpath << j <<" "<< x <<" "<< y <<endl; }
	    
		
      }
   }
   
   for (i=0; i<=Nmax; i++){		// write results into file, including standard error     
      outfile<< i << "  "<<r[i]/Ntrials << "  "<<sqrt(Ntrials)/Ntrials * r[i]/Ntrials << endl;
   }
   cerr << "data stored in walk2d.dat"<< endl;
   cerr << "path #"<<Jrand<<" stored in walkpath2d.dat"<<endl;
   outfile.close();
   outpath.close();
}