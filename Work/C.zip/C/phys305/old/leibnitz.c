#include <stdio.h>
#include <math.h>
void main() {
    int user_input;
    double pi=1.0;
    printf("Enter the number of terms in the Leibniz Series: ");
    scanf("%i", &user_input);
    int a;
    while (a<=user_input) 
    {
        if (a % 2 == 0) {
        double k = 2*a-1;
        pi+=1/k;
        a++;}
        else {
        double k = 2*a-1;
        pi-=1/k;
        a++;}
    }
        double ab=4*fabs(pi);
        printf("Value of Pi: %f \n", ab);
        double c=ab;
        double fracerror=(acos(-1.0)-c)/(acos(-1.0));
        printf("Fractional error: %f \n", fracerror);
    
}