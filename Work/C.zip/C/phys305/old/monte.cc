// hypersphereMC: a monte-carlo integration of a hypersphere volume 
// P. Gorham, updated 2/10/2015 for Physics 305 
// requires student completion 

using namespace std;       
#include <iostream>       
#include <iomanip>   // required to use "setprecision" if needed
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>  
#define PI  M_PI

main(int argc, char *argv[])
{
	double hit,R,Rsq,D,R_D,Vtot,Vsphere;
	int n,i,NDIM=3, Ntrials=10000;
	double xi[Ntrials];
	
	srand48(1299811); // a large prime

	/* usage: NDIM = # of dimensions, NMAX=number of sample points */
	if(argc<2){
		cerr<< "usage: hypersphereMC [NDIM][NMAX]"<<endl;
		exit(0);
		}
	
	NDIM = atoi(argv[1]); // number of dimensions
	Ntrials = atoi(argv[2]); // number of trials



	D= 2.0;		// side of hypercube needed to contain hypersphere
	R_D = 1.0;	// radius of hypersphere
	hit = 0.0;	// the counter for events within sphere
	n=0;		// initialize the loop counter
	
	//-------this is the main loop----------------------

	while(n<Ntrials){  // continue generating coordinates up to Ntrials
	    Rsq = 0.0;  // this variable accumulates the square of each coordinate
	    for(i=0;i<NDIM;i++){
		   xi[i] = (drand48()-0.5)*2.;  // INSERT CALC HERE: uniform random value +/-[0,1] in each coordinate
		   Rsq+=(xi[i])*(xi[i]);  // INSERT CALC HERE: sum up the squares to get distance from origin
		} // end of NDIM loop------------

	        hit += Rsq<=1.0 ? 1.0 : 0.0; // INSERT CALC HERE: check if distance Rsq falls within R_D boundary, 
	          //                   increment hit counter if it does

	    n++;	// counter for Ntrials while loop
	    }  //---------END OF WHILE LOOP-----------------

	Vtot = D;	// Vtot=D for 1-dimensional "hypercube" (a line)
	 for(i=1;i<NDIM;i++){
	        Vtot*=Vtot;  //INSERT CALC HERE: interative multiplication to get N-dim hypercube
	    }

	 /* get ratio of volumes */
	 Vsphere = (hit/Ntrials)*Vtot;  //INSERT CALC HERE: determine the hit ratio & estimated Volume
double Nh=NDIM/2.0;
double g=(NDIM/2.0)+1.0;
double Vtrue = pow(PI,Nh)/(tgamma(g)); // INSERT CALC HERE:  true volume from analytic formula


	 cout << NDIM <<" dimensions, Vsphere= "<< Vsphere <<
	 		"  Vtot= "<<Vtot<<" fractional error= "<<(Vtrue-Vsphere)/Vtrue<<endl;


}