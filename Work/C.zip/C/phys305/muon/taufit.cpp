//  fit a muon decay lifetime
// P. Gorham for Physics 305, spring 2013
// This is just a simple grid search of Chi-squared

using namespace std;  
#include <iostream> 
#include <iomanip>   
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>   
#include <cstdlib> 


#define ND 13

int main(int argc, char *argv[])
{
	ofstream outfile; 
    outfile.open("piongrid.txt");
	outfile.precision(6);
	int i,j,k,l,m,n, gridN, gridTau;
	double times[ND], counts[ND];
	double trialN,trialTau,Chi2,dN,dTau,chimin,nmin,tmin,y,lb,ub;
	double startN,startTau,diff,sigma;
	
	// fix this for any input parameters
	if(argc<2){
		cerr << "usage: pionfit datafile"<< endl;
		}

	
	ifstream infile; 
	infile.open(argv[1]); // command line specifies the name of datafile
	
	for(i=0;i<ND;i++){
		infile >> counts[i] >>  times[i];
		}
		
	infile.close();
	
	for(i=0;i<ND;i++){
	   times[i] = times[i]* 1e-9;
	   //cerr << times[i] <<endl;
	}
	
	dN = 0.10;
	dTau = 1.3e-10;
	gridN = 1000;
	gridTau = 1000;
	chimin = 9999999.9; //large seed
	nmin = 1000.0; 
	tmin = 1000.0;

	startN = 0.0;
	startTau = 1.e-15;
	
	trialN = startN;
	
	//cout <<"#Trial N\tTrial Tau\tChi-squared\tChi-min"<<endl; //print column header

	for(i=0;i<gridN;i++){ //loop over all N,T values
		trialTau = startTau;//reset T for each N
	    for(j=0;j<gridTau;j++){

		Chi2 = 0.0; //reset chi
		
		for(k=0;k<ND;k++){
		  diff = counts[k] -  trialN*exp(-times[k]/trialTau); //displacement from given
		  sigma = 1.+sqrt(counts[k]+0.75); //standard dev
		  Chi2 += (diff*diff)/(sigma*sigma);//chi2
		}
		//outfile<<trialTau<<"\t"<<trialN<<"\t"<<Chi2<<endl;
		chimin = Chi2 < chimin ? Chi2 : chimin; //check if current value is lowest encountered ? set min to this value : else use current
		nmin = Chi2==chimin ? trialN : nmin; //same as above
		tmin = Chi2==chimin ? trialTau : tmin;//ditto
		y = sqrt(2.0*chimin) - sqrt(2.0*ND-1.0); //apply gaussian transform for N>6
		
		ub = 4.49338 + 1.01;
	 	lb = 4.49338 + 0.99;
	 	if(Chi2<ub && Chi2>lb) {
	 		outfile<<Chi2<<"\t"<<trialN<<"\t"<<trialTau<<endl;
	 	}
		
		//cout <<trialN<<"\t"<<trialTau<<"\t"<<Chi2 <<"\t"<<chimin<<"\t"<<nmin<<"\t"<<tmin<<"\t"<<y<<endl;
		trialTau += dTau; //increment T; close T loop
	   }
	   trialN += dN; //increment N; close N loop
	 }
	 cout<<chimin<<"\t"<<nmin<<"\t"<<tmin<<"\t"<<y<<endl;
	 //now need to vary chi around minimum
	 
	 
	 
	 
	 
	/* double ntest, ttest, nm, tm, cm;
	 nm = nmin-dN/2.0;
	 tm = tmin-dTau/2.0;
	 cm = 999999.9;
	 ntest = nm;
	 for(l=0;l<gridN;l++){
	 	ttest = tm;

	 	for(m=0;m<gridTau;m++){
	 		Chi2 = 0.0;
	 		for(n=0;n<ND;n++){
	 			diff = counts[n] -  ntest*exp(-times[n]/ttest);
				sigma = 1.+sqrt(counts[n]+0.75);
				Chi2 += (diff*diff)/(sigma*sigma);
	 		}
	 	ub = chimin + 10.0;
	 	lb = chimin + 10.0;
	 	if(Chi2<ub && Chi2>lb) {
	 		cout<<Chi2<<"\t"<<ntest<<"\t"<<ttest<<endl;
	 	}
	 	
	 	
	 	
	 	
	 	//cm = Chi2 < (cm+1.01) && Chi2 > (cm+0.99) ? Chi2 : cm;
		//nm = Chi2==cm ? ntest : nm;
		//tm = Chi2==cm ? ttest : tm;
		//outfile<<cm<<"\t"<<
		//cout<<cm<<"\t"<<tm<<"\t"<<nm<<endl;	
		ttest += dTau/gridTau;
	 	}
	 	ntest += dN/gridN;
	 }*/
//cout<<chimin<<"\t"<<lb<<"\t"<<ub<<endl;

}