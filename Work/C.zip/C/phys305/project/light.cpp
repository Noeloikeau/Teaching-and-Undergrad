//Noeloikeau Charlot 4/12/2017
//program to propagate equations of motion for light in arbitrary optical field
//using 3Vector.h, 3Vector.cpp, vecFRK4xv.cpp by P. Gorham
//these files define vector operations and fourth order runge-kutta integration

using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include "3Vector.h"
#include "3Vector.cpp"
#include "vecFRK4xv.cpp"
#define Tmax  10000        
#define PI M_PI
#define c 1.0 //speed of light

double t0, theta0, phi0;

//let capitol letters denote vectors
vec3 O,P; //O is origin, P is previous position

//this function updates position by calling velocity
vec3 fr(double t, vec3 R, vec3 V)  //R is current position, V current velocity
{
	return(V);
}
//this function updates velocity by calling position
vec3 fv(double t, vec3 R, vec3 V)  
{
	O.x = 0.0;
	O.y = 0.0;
	O.z = 0.0;
	vec3  A, dR; //A is acceleration, dR change in position, F force 
	dR = vec3diff( R, O); //diff from origin - is this needed?
	double r; //magnitude of dR vector 
	r = vec3mag(dR); 
	//n = 1.0/r;
	A.x = (-2.0*V.x*(R.y*V.y+R.z*V.z)+R.x*(-V.x*V.x+V.y*V.y+V.z*V.z))*2.0/(r*r);
	//(R.x*V.x*V.x+2.0*R.y*V.x*V.y-R.x*V.y*V.y)*2.0/(r*r);
	A.y = (-2.0*V.y*(R.x*V.x+R.z*V.z)+R.y*(V.x*V.x-V.y*V.y+V.z*V.z))*2.0/(r*r);
	//(-R.y*V.x*V.x+2.0*R.x*V.x*V.y+R.y*V.y*V.y)*2.0/(r*r);
	A.z = 0.0;//(-2.0*V.z*(R.x*V.x+R.y*V.y)+R.z*(V.x*V.x+V.y*V.y-V.z*V.z))*2.0/(r*r);

	return(A); // return the acceleration
}

extern vec3 vecFRK4xv(int ytype, vec3 (*f_x)(double, vec3, vec3),
			  vec3 (*f_v)(double, vec3, vec3), 
			double t, vec3 xold,vec3 vold,double dt);

main(int argc,char *argv[])
{
  double t, dt, Ttot, V0;
  vec3 Ri,Vi,Q; //Ri is integrated position, Vi integrated velocity, Q previous velocity
  ofstream outfile; 

    outfile.open("circles.txt");
	Ttot = 100.0;
	t0 = 0.0;     			  
	dt = 0.01;
	theta0 = PI/2.0;
	phi0 = PI/4.0;

	V0 = c;

	Q.x = V0*cos(theta0);//*sin(phi0);                    
	Q.y = V0*sin(theta0);//*sin(phi0);
	Q.z = 0.0;//V0*cos(phi0);                     

	P.x = 1.0;
	P.y = 0.0;  
	P.z = 0.0;


	for(t=t0; t<Ttot; t+= dt){

		Ri = vec3sum( P , vecFRK4xv(0,fr,fv,t,P,Q,dt) );
		Vi = vec3sum( Q , vecFRK4xv(1,fr,fv,t,P,Q,dt) );

		P = Ri;
		Q = Vi; 
	
		outfile << Ri.x << "\t" <<  Ri.y << "\t" << Ri.z << "\t" <<endl; 
	} //end integral

}  



