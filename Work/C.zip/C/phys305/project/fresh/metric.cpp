using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 

#define c 299792e3
#define G 6.674e-11
#define dG 31e-6
#define PI M_PI
#define MSUN 1.988435e30
#define MBH 4.1e6*MSUN

metric


main(){
        double M = 
}
