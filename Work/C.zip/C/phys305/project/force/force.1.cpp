using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USS_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include "3Vector.h"
#include "3Vector.cpp"
#include "vecFRK4xv.cpp"

#define RS  6.957000000000000000000000000000000e8      //sun radius
#define G   6.673000000000000000000000000000000e-11   //newton
#define RM  2.439690000000000000000000000000000e6	 //mercury radius  
#define M   1.988435000000000000000000000000000e30   //sun mass   
#define m   3.301040000000000000000000000000000e23    //mercury mass
#define D   7.030000000000000000000000000000000e10      //sun mercury distance @ aphelion
#define c   299792458.0000000000000000000000000      //speed of light
#define mu  M*m/(M+m)     //reduced mass mercury sun system
#define rs  2.0*G*M/(c*c) //schwarzschild radius of sun
#define PI  M_PI          
#define V0  38.7000000000000000000000000000000e3        //mercury speed at aphelion 

double t0;

vec3 P; 

vec3 fr(double t, vec3 R, vec3 V) 
{
	return(V);
}


vec3 fv(double t, vec3 R, vec3 V)  
{

	vec3  A;

	A.x = -1.0/(R.x*R.x)+V.y*V.y*(R.x-3.0);

	A.y = -2.0*V.x*V.y/R.x;

	A.z = 0;

	return(A); 
}

extern vec3 vecFRK4xv(int ytype, vec3 (*f_x)(double, vec3, vec3),
			  vec3 (*f_v)(double, vec3, vec3), 
			double t, vec3 xold,vec3 vold,double dt);

main(int argc,char *argv[])
{
  double t, dt, Ttot, T;
  vec3 Ri,Vi,Q; 
  ofstream outfile; 
	outfile.precision(5);
    outfile.open("mercury1.txt");
    T = 1.0e4;
    dt = 0.1;
	t0 = 0.0;     			  

	Q.x = 0.01;                    
	Q.y = 0.01;
	Q.z = 0;                    

	P.x = 20.0;
	P.y = 0.0;  
	P.z = 0.0;


	for(t=t0; t<T; t+=dt){
	
		
		Ri = vec3sum( P , vecFRK4xv(0,fr,fv,t,P,Q,dt) );
		Vi = vec3sum( Q , vecFRK4xv(1,fr,fv,t,P,Q,dt) );

		P = Ri;
		Q = Vi; 
		outfile << P.x*cos(P.y) <<"\t"<< P.x*sin(P.y) <<"\t"<<t<< endl;
	} //cout << atan(Ri.y) << "\t" << t <<endl;
}  
