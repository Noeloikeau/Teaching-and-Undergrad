/* 4-vector cartesian include file */
/* Noeloikeau Charlot 4/13/2017
/* Updated from P. Gorham 4/10/13 3-vector include file*/

#ifndef VECTOR_INCLUDED
#define VECTOR_INCLUDED

#include <cmath>

/* this structure type is for a 4-d vector */
typedef struct {
		double x, y, z, t;
		} vec4;

/*  general vector functions */

vec4  vec4sum( vec4 , vec4 );  // sum of two vectors

vec4  vec4diff( vec4 , vec4 );  // difference of two vectors

vec4  scalar_vec4sum( double , vec4 ); // sum of scalar and vector


double vec4mag (vec4 );  // _magnitude of vector


vec4  scalar_vec4mult( double , vec4 );  // scalar times vector

double vec4dot ( vec4 , vec4  );  // dot product

//vec4 vec4cross ( vec4 , vec4  );  // cross product undefined in 4d


vec4 vec4norm ( vec4  );  // return unit vector for _A 


// add 3 vectors at once
vec4  vec4sum3( vec4 , vec4 , vec4 );

// add 4 vectors at once
vec4  vec4sum4( vec4 , vec4 , vec4 , vec4 );


#endif