//Noeloikeau Charlot 4/12/2017
//program to propagate equations of motion for light in arbitrary optical field
//using 3Vector.h, 3Vector.cpp, vecFRK4xv.cpp by P. Gorham
//these files define vector operations and fourth order runge-kutta integration

using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include "4Vector.h"
#include "4Vector.cpp"
#include "vecFRK4xv.cpp"
#define PI M_PI
#define rs 0.10000000000

double t0, t, dt, Ttot;
//let capital letters denote vectors
vec4 P,Q,Ri,Vi; //P is current position, Q current velocity, Ri integrated position, Vi integrated velocity

//this function returns velocity
vec4 fr(double t, vec4 R, vec4 V)  //R is given position, V given velocity
{
	return(V);
}

//this function returns acceleration
vec4 fv(double t, vec4 R, vec4 V){

	vec4  A; //A is acceleration
	double rx,rz,vx,vz; //intermediate variables for coordinate transformation from cartesian input to polar used in metric
	
	rx = sqrt(R.x*R.x+R.z*R.z); //radius r
	
	rz = atan(R.z/R.x);			//plane angle phi
	
	vx = (R.x*V.x+R.z*V.z)/rx;  //radial velocity rdot
	
	vz = (R.x*V.z-R.z*V.x)/(rx*rx); //angular velocity phidot
	
	A.t = V.t*vx*rs/(rx*rx*(1.0+rs/rx)); //metric equations
	
	A.x = (1.0+rs/rx)*rs/(2.0*rx*rx)*V.t*V.t-rs/(2.0*rx*rx*(1.0+rs/rx))*vx*vx+(1.0+rs/rx)*rx*vz*vz;

	A.y = 0;

	A.z = -(2.0/rx)*vz*vx;

	return(A); // return the acceleration
}

extern vec4 vecFRK4xv(int ytype, vec4 (*f_x)(double, vec4, vec4),
			  vec4 (*f_v)(double, vec4, vec4), 
			double t, vec4 xold,vec4 vold,double dt);

main(int argc,char *argv[])
{
	vec4 P,Q,Ri,Vi;
	double t0, t, dt, Ttot;

    ofstream outfile; 
    outfile.open("schwarz2d0.txt");
    outfile.precision(5);
   
	Ttot = 10.0;
	t0 = 0.0;     			  
	dt = 0.001;

	P.x = 0.15;
	P.y = 0.0; 
	P.z = 0.0;
	P.t = 1.0;

	Q.x = -0.1;
	Q.y = 0.0;
	Q.z = 0.0;
	Q.t = 1.0;


	for(t=t0; t<=Ttot; t+= dt){
		outfile << P.x << "\t" << P.z << "\t" << t <<endl;
		Ri = vec4sum( P , vecFRK4xv(0,fr,fv,t,P,Q,dt) );
		Vi = vec4sum( Q , vecFRK4xv(1,fr,fv,t,P,Q,dt) );
		//dt = sqrt(Ri.x*Ri.x+Ri.z*Ri.z)/rs < 1.5 ? 0.000001 : 0.01;
		t = sqrt(Ri.x*Ri.x+Ri.z*Ri.z) > rs ? t : Ttot;
		P = Ri;
		Q = Vi;
	}
		
}  



