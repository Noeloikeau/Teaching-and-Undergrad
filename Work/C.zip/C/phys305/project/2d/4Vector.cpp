// example of how to use typedef for a 3vector, along with
//some vector function definitions --P. Gorham 3/10/03 for P305 
// updated to c++ March 2013

#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
using namespace std;

#include "4Vector.h"

		
// these are general vector routines. Functions that return vectors must be returned to a vector
// , must pass vectors back and forth



vec4  vec4sum( vec4 _A, vec4 _B)  // sum of two vectors
{
	vec4 _tmp;
	_tmp.x = _A.x + _B.x;
	_tmp.y = _A.y + _B.y;
	_tmp.z = _A.z + _B.z;
	_tmp.t = _A.t + _B.t;

	return(_tmp);
}
vec4  vec4diff( vec4 _A, vec4 _B)  // difference of two vectors
{
	vec4 _tmp;
	_tmp.x = _A.x - _B.x;
	_tmp.y = _A.y - _B.y;
	_tmp.z = _A.z - _B.z;
	_tmp.t = _A.t - _B.t;
	return(_tmp);
}
vec4  scalar_vec4sum( double _A, vec4 _B) // sum of scalar and vector
{
	vec4 _tmp;
	_tmp.x = _A + _B.x;
	_tmp.y = _A + _B.y;
	_tmp.z = _A + _B.z;
	_tmp.t = _A + _B.t;
	return(_tmp);
}

double vec4mag (vec4 _A)  // _magnitude of vector
{
	return( sqrt(_A.x*_A.x+_A.y*_A.y+_A.z*_A.z+_A.t*_A.t));
}

vec4  scalar_vec4mult( double _A, vec4 _B)  // scalar times vector
{
	vec4 _tmp;
	_tmp.x = _A*_B.x;
	_tmp.y = _A*_B.y;
	_tmp.z = _A*_B.z;
	_tmp.t = _A*_B.t;
	return(_tmp);
}
double vec4dot ( vec4 _A, vec4 _B )  // dot product
{
	double _tmp;
	_tmp = _A.x*_B.x + _A.y*_B.y + _A.z*_B.z + _A.t*_B.t;
	return(_tmp);
}
/*vec4 vec4cross ( vec4 _A, vec4 _B )  // cross product
{
	vec4 _tmp;
	_tmp.x = _A.y*_B.z - _A.z*_B.y;
	_tmp.y = _A.z*_B.x - _A.x*_B.z;
	_tmp.z = _A.x*_B.y - _A.y*_B.x;
	return(_tmp);
}*/

vec4 vec4norm ( vec4 _A )  // return unit vector for _A 
{	
	vec4 _tmp;
	double _mag;
	_mag = sqrt(_A.x*_A.x+_A.y*_A.y+_A.z*_A.z+_A.t*_A.t);
	_tmp.x = _A.x/_mag;
	_tmp.y = _A.y/_mag;
	_tmp.z = _A.z/_mag;
	_tmp.t = _A.t/_mag;
	return(_tmp);
}

// add 3 vectors at once
vec4  vec4sum3( vec4 X, vec4 Y, vec4 Z)
{
	vec4 tmp;
	tmp.x = X.x+Y.x+Z.x;
	tmp.y = X.y+Y.y+Z.y;
	tmp.z = X.z+Y.z+Z.z;
	tmp.t = X.t+Y.t+Z.t;
	return(tmp);
}
// add 4 vectors at once
vec4  vec4sum4( vec4 W, vec4 X, vec4 Y, vec4 Z)
{
	vec4 tmp;
	tmp.x = W.x+X.x+Y.x+Z.x;
	tmp.y = W.y+X.y+Y.y+Z.y;
	tmp.z = W.z+X.z+Y.z+Z.z;
	tmp.t = W.t+X.t+Y.t+Z.t;
	return(tmp);
}