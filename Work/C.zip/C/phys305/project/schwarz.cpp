//Noeloikeau Charlot 4/12/2017
//program to propagate equations of motion for light in arbitrary optical field
//using 3Vector.h, 3Vector.cpp, vecFRK4xv.cpp by P. Gorham
//these files define vector operations and fourth order runge-kutta integration

using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#define USE_MATH_DEFINES
#include <cmath>
#include <cstdlib> 
#include "4Vector.h"
#include "4Vector.cpp"
#include "vecFRK4xv.cpp"
#define Tmax  10000        
#define PI M_PI
#define c 1.0 //speed of light

double t0, theta0, phi0;

//let capitol letters denote vectors
vec4 O,P; //O is origin, P is previous position

//this function updates position by calling velocity
vec4 fr(double t, vec4 R, vec4 V)  //R is current position, V current velocity
{
	return(V);
}
//this function updates velocity by calling position
vec4 fv(double t, vec4 R, vec4 V)  
{
	O.x = 0.0;
	O.y = 0.0;
	O.z = 0.0;
	O.t = 0.0;
	vec4  A, dR; //A is acceleration, dR change in position, F force 
	double rs; //schwarzschild radius
	rs = 0.1;
//	V.t = 1.0/(sqrt(1.0-vec4mag(V)*vec4mag(V))*sqrt(1.0-rs/r));
	
	A.x = (-rs*V.x*V.x/(2.0*R.x)+R.x*rs*R.y*R.y/(2.0*pow((R.x-rs),2.0))-R.x*R.x*V.z*V.z-R.x*R.x*sin(R.y)*sin(R.y)*V.t*V.t)/(R.x-rs);

	A.y = rs*V.x*V.y/(R.x*R.x-R.x*rs)+R.x*(R.x-rs)*cos(R.y)*sin(R.y)*V.t*V.t;

	A.z = -2.0*V.x*V.z/R.x;
	
	A.t = -2.0*(V.x+R.x*tan(PI/2.0-R.y)*V.y)*V.t/R.x;

	return(A); // return the acceleration
}

extern vec4 vecFRK4xv(int ytype, vec4 (*f_x)(double, vec4, vec4),
			  vec4 (*f_v)(double, vec4, vec4), 
			double t, vec4 xold,vec4 vold,double dt);

main(int argc,char *argv[])
{
  double t, dt, Ttot, V0;
  vec4 Ri,Vi,Q; //Ri is integrated position, Vi integrated velocity, Q previous velocity
  ofstream outfile; 

    outfile.open("schwarz.txt");
	Ttot = 100.0;
	t0 = 0.0;     			  
	dt = 0.01;
	theta0 = PI/2.0;
	phi0 = 0.0;

	V0 = c;
	
	P.x = sqrt(3.0);
	P.y = 0.9553166; //arcsin(sqrt(2/3)) : position vector for (1,1,1)  
	P.z = PI/4.0;
	P.t = 0.0;

	Q.x = V0*cos(P.y)*sin(P.z);                    
	Q.y = V0*sin(P.y)*sin(P.z);
	Q.z = V0*cos(P.z);
	Q.t = 1.0;


	for(t=t0; t<Ttot; t+= dt){
	
		Ri = vec4sum( P , vecFRK4xv(0,fr,fv,t,P,Q,dt) );
		Vi = vec4sum( Q , vecFRK4xv(1,fr,fv,t,P,Q,dt) );

		P = Ri;
		Q = Vi; 
	
		outfile << Ri.x*cos(Ri.z)*sin(Ri.y) << "\t" <<  Ri.x*sin(Ri.z)*sin(Ri.y) << "\t" << Ri.x*cos(Ri.y) << "\t" << Ri.t << "\t" << t <<endl; 
		//outfile << Ri.x << "\t" <<  Ri.y << "\t" << Ri.z << "\t" << Ri.t << "\t" << t <<endl; 
	} //end integral

}  



