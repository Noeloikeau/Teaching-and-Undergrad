using namespace std;       
#include <iostream>       
#include <iomanip>   // this is required to use "setprecision" below
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>           
#include <vector>
using std::vector;
double get_xvalue( void );
double func(double x);
 
main(int argc, char *argv[])
{
	int xval;
	int i;
	int N=1000000;
	vector<int> l;
	l.resize(N);
	// simple driver routine to check Poisson below
	for(i=0;i<N;i++){
		xval = (int)get_xvalue(); 
		++l[xval];
		//cout << xval << endl;
		}
	for (int j=0; j<=20; ++j) {
		cout<< j << " " << l[j] <<endl;
	}
}

//-----------------------------------------------------------------
// Uses von Neuman method to get random values distributed according
// to a functional form, function should be positive definite
double get_xvalue( void )
{
	double x,W,fx,fxmax,xmax,m;
	
	fxmax = 1.0;  // this depends on the desired height of the function
			// it must bound the function from above
	m = 1; //mass in grams
	xmax = 15; // this depends on the desired range of the function!
			// it must bound the function from the left
			// and if the range can go negative, then
			// it requires an offset translation of the result
	W = fxmax;
	fx = -99.;
	while(W>fx){   
		W = fxmax*(drand48());  // this samples the height
		x= xmax*drand48();  // this sets the domain
		fx =  func(x);
	}
	return(x);
}

// Here is the function we want our distribution to follow
double func(double x)
{
	double mu=0.085;  // a test value, Poisson 
	return(pow(mu,x)*exp(-mu)/exp(lgamma(x+1.))); // Poisson distribution
}
