using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI
#define M 1000000
#define Q 0.001
#define seed 6811111
main(){
    srand48(seed);
    vector<double> x,y,z,l;
  x.resize(M); //randomized data, smallest time scale
  y.resize(M); //counter on data checking if below threshold
  z.resize(200); //rebinned counter, larger time scale
  l.resize(200); //frequency distribution, increments for values of z each time they occur
  double j = 0;
  double r= 0;
  for (int i=0; i<M; ++i) {
      x[i]=drand48();
      y[i]= x[i]<=Q ? 1.0 : 0;
      j = i/(6000);
      r = (i+1)/(6000);
      z[j]+=y[i];
      l[z[j]]+= r>j ? 1.0 : 0; //if minute changes, increment 
      }

  for(int k=0; k<=20; ++k){
      cout<< " " << "z[" << k << "]: " << l[k] << endl; 
  } 
}