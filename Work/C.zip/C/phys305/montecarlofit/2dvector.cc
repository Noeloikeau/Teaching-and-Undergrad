using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI
#define M 1000000
#define N 10 //MxN matrix
#define Q 0.1
#define seed 681111
main(){
    srand48(seed);
    vector<vector<double> > x;
    vector<vector<double> > y;
    vector<double> z;
  x.resize(M);
  y.resize(M);
  z.resize(N);
  for (int i=0; i<M; ++i) {
        x[i].resize(N);
        y[i].resize(N);
    for (int j=0; j<N; ++j) {
        x[i][j]=drand48();
        if (x[i][j]<Q) {
            ++y[i][j];
            ++z[j];
        }
    }
  }
  
  for(int i=0; i<100; ++i) {

  for(int j=0; j<N; ++j){
      cout<< "i: " << i << ", j: " << j << ", y[" << i << "]" << "[" << j << "]: " << y[i][j] << endl;
  }
  }
  return 0;
}
    