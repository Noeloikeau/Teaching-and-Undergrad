/* Isotope1.cpp: program to simulate radioactive decay
 * -- P. Gorham for UH Physics 305 2/24/14 
 * g++ Isotope1.cpp -o Isotope1
 */

using namespace std;       // sets up some standard names for things
#include <iostream>        // This is  library containing input-output functions
#include <iomanip>   // this is required to use "setprecision" 
#include <fstream>
#define _USE_MATH_DEFINES  // tells the compiler to define math constants (like pi) for you
#include <cmath>
#include <cstdio>     // for the  useful old C-standard stuff 
#include <cstdlib>    
#include <vector>
using std::vector;

#define LONGENOUGH  10000
    
main(int argc, char *argv[])
{

	if(argc<2){
		cerr<< "Input: #C12, #C11, #C10"<<endl;
		exit(0);
		}
	
	int Natoms0 = atoi(argv[1]); 
    int Natoms1 = atoi(argv[2]);
    int Natoms2 = atoi(argv[3]);
   
    double Lifetime1 = 1000;
    double Lifetime2 = 100;
    
   

    double *DecayArr, *RemainArr,*DecayArr1, *RemainArr1,*DecayArr2, *RemainArr2;   
    double dt = 0.1;  
    double bindt = 10.0;
    double dt_DecayProb1 = dt/Lifetime1;  
    double dt_DecayProb2 = dt/Lifetime2;
    int Ndecay1, Ndecay2, Nt0, Nt1, Nt2, Nt, Nd;
    int TotalTime = LONGENOUGH; 
  
    srand48(1299811); 
    double tt = 0.0;   
    
    Nt0 = Natoms0;
    Nt1 = Natoms1; 
    Nt2 = Natoms2;

    Nt = Nt0+Nt1+Nt2;
    
    int Ndeltat = LONGENOUGH/bindt;   
    DecayArr = new double [Ndeltat](); 
    RemainArr = new double [Ndeltat]();
    DecayArr1 = new double [Ndeltat](); 
    RemainArr1 = new double [Ndeltat]();
    DecayArr2 = new double [Ndeltat](); 
    RemainArr2 = new double [Ndeltat]();
    
    while(tt < TotalTime) {          
        Ndecay1 = 0; 
        Ndecay2 = 0;

        for(int i=0;i<Nt1;i++){ 
        int idecay1 = drand48() <= dt_DecayProb1 ? 1 : 0 ; 
           if(idecay1){
              DecayArr1[(int)(tt/bindt)] += 1.0; 
              Ndecay1 += 1;
            }
        }
        Nt1-=Ndecay1;
        for(int i=0;i<Nt2;i++){
            int idecay2 = drand48() <= dt_DecayProb2 ? 1 : 0 ;
            if(idecay2){
              DecayArr2[(int)(tt/bindt)] += 1.0; 
              Ndecay2 += 1;
            }
        }       
        Nt2-=Ndecay2;
        Nt -= Ndecay1+Ndecay2;
        DecayArr[(int)(tt/bindt)] = DecayArr1[(int)(tt/bindt)] + DecayArr2[(int)(tt/bindt)];
        RemainArr1[(int)(tt/bindt)] = Nt1;
        RemainArr2[(int)(tt/bindt)] = Nt2;
        RemainArr[(int)(tt/bindt)] = Nt;
        
        tt += dt;      
    } 
   
    for(int i=0;i<Ndeltat;i++){
        cout << (i+0.5)*bindt <<" "<<DecayArr1[i]<<" "<<DecayArr2[i]<<" "<<DecayArr[i]<<" "<<RemainArr[i]<<endl;  
        }

}