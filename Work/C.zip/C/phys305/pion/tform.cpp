using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#define _USE_MATH_DEFINES  
#define ND 100
main(){
    double x1[200], y1[200], E1[200], x2[200], y2[200], E2[200], m[200], u[200], t[100], w;
    double Z = 2700.0;
    double n = 0.0;
    double a = 0.0;
    ifstream infile;
	infile.open("481X2t.txt");
	ofstream outfile;
	outfile.open("481X2T.txt");
    int	i=0;
	for(i=0;i<ND;i++){
		infile >> x1[i] >> y1[i] >> E1[i] >> x2[i] >> y2[i] >> E2[i];
		m[i] = 2.0*sqrt(E1[i]*E2[i])*sin(0.5*(atan(sqrt(x1[i]*x1[i]+y1[i]*y1[i])/Z)+atan(sqrt(x2[i]*x2[i]+y2[i]*y2[i])/Z)));
		u[(int)m[i]] += m[i] > 0.0 ? 1.0 : 0.0;
	    } 
	for(i=120;i<150;i++){
	    if(u[i]>0.1){
	    outfile<<i<<"\t"<<u[i]<<endl;
	    }
	}
}   

