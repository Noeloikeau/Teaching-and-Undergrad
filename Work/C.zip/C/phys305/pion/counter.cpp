using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#define _USE_MATH_DEFINES  
#define ND 100
main(){
    double x1[200], y1[200], E1[200], x2[200], y2[200], E2[200], z[200], b[200];
    double Z = 2700.0;
    ifstream infile;
	infile.open("481X2.txt");
	ofstream outfile;
	outfile.open("481X2t.txt");
    int	i=0;
	for(i=1;i<ND;i++){
		infile >> x1[i] >> y1[i] >> E1[i] >> x2[i] >> y2[i] >> E2[i] >> z[i] >> b[i];
		if(E1[i] > 0.0 && E2[i] > 0.0){
		    outfile << x1[i] << "\t" << y1[i] << "\t" << E1[i] << "\t" << x2[i] << "\t" << y2[i] << "\t" << E2[i] <<endl;
		} 
	} 
}   

