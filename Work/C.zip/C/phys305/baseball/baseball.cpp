/* projectile motion of a struck baseball */
/* P. Gorham, 3/19/2014 for UH Physics 305 */
// g++ 3Vector.o vecFRK4xv.o baseball.cpp  -o ~/bin/baseball -lm

using namespace std;       
#include <iostream>       
#include <iomanip>   // this is required to use "setprecision" below
#include <fstream>
#define _USE_MATH_DEFINES  
#include <cmath>        
#include <cstdio>     // for the  useful old C-standard stuff 
#include <cstdlib>    
#include "3Vector.h"
#include "3Vector.cpp"
#include "vecFRK4xv.cpp"

//--------------------------------------
// Defined quantities--usually put into ".h" include files
// if there are enough of them and they don't ever change:

#define Tmax  500                // seconds
#define PI M_PI
#define rho_airSL 1.22          //kg/m^3
#define Cd 0.35
#define Aball  (PI*0.0738*0.0738/4.)  // area of ball, diam 7.38cm
#define m  0.145                     // kg, mass of the baseball
#define H0  7000.0                   // scale height of atmosphere
#define g 9.8066            /* m/s/s, local gravity */
#define MPH2mps  0.44704



//-----------------------------------
// global variable for wind velocity
vec3 W0;
// global altitude
double Altitude;
// global flag for drag usage
bool dragON = true;
//----------------------------------
// Function prototypes:
double dragc( double h);
vec3 vecFRK4xv(int, vec3 (*f_x)(double, vec3, vec3),
			  vec3 (*f_v)(double, vec3, vec3), 
			double , vec3 ,vec3 ,double );

 vec3 f_x(double t, vec3 x, vec3 v), f_v(double t, vec3 x, vec3 v);
//----------------------------------

//===============begin main====================

main( int argc, char **argv){ 
	 ofstream outfile; 
    outfile.open("baseball.txt");
	outfile.precision(5);
  vec3 xt,vt,xtold,vtold;
 
  double t,t0, theta0;
  double dt;
  double vt0,v0;


	if(argc<6){
	fprintf(stderr, "usage: baseball [theta0 (deg)][v0 (m/s)][wind v(mph)][Alt(m)][drag on=1 off=0] > outfile\n");
		exit(0);
		}

	

	theta0 = PI/180.0*atof(argv[1]);   // initial angle, coverted to radians
	v0 = atof(argv[2]);                // initial velocity, m/s
	W0.x = atof(argv[3])*MPH2mps;      // wind velocity, x horizontal 
	W0.y=W0.z=0.0;
	Altitude= atof(argv[4]);           // Altitude of stadium
	dragON = atoi(argv[5]);            // 1==true 0==false
	vtold.x = v0*cos(theta0);          // x and z components of velocity
	vtold.z = v0*sin(theta0);
	vtold.y = 0.0;                     //  in plane motion only here
	t0 = 0.0;                          // initial time
	xtold.x = xtold.y=0.0;                     // initial position at origin
	xtold.z = Altitude;
	dt = 0.01;                         // time step, s


	/* start by printing the initial conditions, note old C-style printing*/
	fprintf(stdout,"%e\t%e\t%e\t%e\t%e\n",
			    t,xtold.x,xtold.z-Altitude,vtold.x,vtold.z);

	for(t=t0; t<Tmax; t+= dt){

		xt = vec3sum( xtold , vecFRK4xv(0,f_x,f_v,t,xtold,vtold,dt) );
		vt = vec3sum( vtold , vecFRK4xv(1,f_x,f_v,t,xtold,vtold,dt) );

		xtold = xt;
		vtold = vt;

		if(xt.z<Altitude){
		 	fprintf(stdout,"%e\t%e\t%e\t%e\t%e\n",
			    t,xt.x,xt.z-Altitude,vt.x,vt.z);
			 break;
			 }
		fprintf(stdout,"%e\t%e\t%e\t%e\t%e\n",
			    t,xt.x,xt.z-Altitude,vt.x,vt.z);
			    outfile << t << "  " << xt.x << "  " << xt.z << endl;
	   }


}

// ========end main===========================

// functions follow:


vec3 f_x(double t, vec3 x, vec3 v)
{
	return(v);
}



vec3 f_v(double t, vec3 x, vec3 v)
{
	double  h, b, vmag;
	vec3 atot, agrav, adrag, vapp;

	// the height, including height of fly ball,
	// though its small compared to altitude of
	// stadium
	h = x.z + Altitude; // include altitude of ball above stadium
	
	b = dragc(h);               // air drag term
	
	// drag force Fd = 0.5*(air density)*Cd*A*v^2 
	// drag factor in -bv^2 is then: b = 0.5*rho*Cd*A
	agrav.x = agrav.y = 0.0;
	agrav.z = -g;
	
	vapp = vec3diff(v,W0); 
	vmag = vec3mag(vapp);

	adrag = scalar_vec3mult(-b/m*vmag, vapp);
	atot = vec3sum(agrav,adrag);

	return(atot);
}


double dragc(double H)
{
	double b0, b;
      if(dragON){
	b0 = 0.5*rho_airSL*Cd*Aball;
	return ( b = b0*exp(-H/H0) );  // just scale by change in density
      }else{
	return ( b = 0 );
      }
}






	
	
	
	