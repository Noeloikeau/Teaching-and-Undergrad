using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI
#define M 10002
#define N 10000
#define seed 681111
main(){
    double k1, k2, k3, ktot, rhob, c, E, Es, Ed, Pa, Pb, R1, R2, t, twait, n, cp, cm, o;
    int i,j;
    ofstream outfile; //declaring outfile
	outfile.open("amyloid.txt"); //opening outfile
	//select seed randomly from set of seeds
for(c=0.15; c<=0.5; c+=0.001){
    j=0;
    vector<double> x;
    x.resize(M);
    srand48(seed);
    Es = 1.0; //same energy
    Ed = 2.0; //diff energy
    rhob = 0.500; //ratio of type b to a
    n = 0.0; //array length counter
    cp = 0.0; //type + counter
    cm = 0.0; //type - counter
    k1 = rhob*c; //+ reaction constant
    k2 = (1.000-rhob)*c; //- reaction constant
    
    o = 0.0; //order parameter
    //ktot = k1+k2+k3; //net reaction constant
    t = 0.0; //net time
    x[0] = drand48() >= rhob ? 1.0 : -1.0;
    for (int i=1; i<=N && j<=N; i++) { //loop over array
        R1 = drand48(); //generate first random number
        if(i>=2){
            E = x[i-2] == x[i-1] ? Es : Ed; //determine energy condition 
            k3 = exp(-E); //set decay rate constant
            ktot = k1+k2+k3; //reset total reaction constant
        } else {
            ktot = k1+k2;
        }
        //if between 0 and k1/ktot: event 1; else if between k1/ktot and (k1+k2)/ktot: event 2; else if between (k1+k2)/ktot and 1: event 3
        if (R1<=k1/ktot) {
            x[i] = 1.0; //+ type
        } 
        if (R1<=(k1+k2)/ktot && R1>k1/ktot) {
            x[i] = -1.0; //- type
        }
        if (R1>(k1+k2)/ktot) {
            x.erase(x.begin() + i-1); //erase last element
            i = i-2; //return to previous position
            //outfile<<"erased"<<" "<<i<<" "<<x[i]<<endl;
        }
        
        R2 = drand48(); //generate second random number
        twait = -log(1.0-R2)/ktot; //set wait time for current step
        t += twait; //increment net time
        
        //outfile<<j<<" "<<i<<" "<<x[i]<<endl;
        j++;
    }
    //1: low conc, show grow mostly 50/50 A/B (tune Eaa lower, Ebb lower, Eab higher [higher binding between AB than alone])
   
        for(i=1; i<=N; i++){ //loop over complete array
            if (x[i]==1.0 || x[i]==-1.0){ //determine type
                n++; //increment array length counter
                cp+= x[i]==1.0 ? 1.0 : 0.0; //conditional for type +
                cm+= x[i]==-1.0 ? 1.0 : 0.0; //conditional for type -
                o+= x[i]*x[i+1]; //order parameter increment
            }//if close
        }//array count loop close
    //cout<<n<<" "<<cp<<" "<<cm<<" "<<t<<" "<<n/t<<" "<<o<<" "<<o/(n-1.0)<<endl;
    outfile<<c<<"\t"<<n<<" "<<o/(n-1.0)<<endl;
    }//conc loop close
} //main close
    