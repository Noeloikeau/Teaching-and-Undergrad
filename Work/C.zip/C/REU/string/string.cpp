using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI
#define M 10002
#define N 10000
#define seed 681111
main(){ 
        int n = 3;
        /*string filename;
        ofstream outfile;
        filename = 1hi ;
        outfile.open( filename.c_str() );
        outfile<<"hi"<<i<<endl;
        outfile.close();*/
    for(int j=0; j!=n; ++j) {
    for(int i=0; i!=n; ++i) {
     
     std::string name="file_" + std::to_string(i) + std::to_string(j) + ".txt"; // C++11 for std::to_string 
     
     ofstream outfile;
     outfile.open(name);
     outfile<<"hi"<<i<<endl;
     
    }
 }
}