using namespace std;       
#include <iostream>       
#include <iomanip> 
#include <fstream>
#include <cmath> 
#include <cstdlib> 
#include <vector>
using std::vector;
#define _USE_MATH_DEFINES  
#define PI  M_PI
#define M 10002
#define N 10000
#define seed 681111
main(){
    double k1, k2, k3, ktot, rhob, rstart, rend, rinc, c, E, Es, Ed, Pa, Pb, R1, R2, t, twait, n, cp, cm, o, m, cstart, cend, cinc;
    int i,j;
    
	//select seed randomly from set of seeds
	cstart = 0.001;
	cend = 1.00;
	cinc = 0.001;
    rstart = 0.1; //ratio of type b to a
    rend = 0.9;
    rinc = 0.1;
    Es = 1.0; //same energy
    Ed = 1.0; //diff energy
for(Ed=1.0; Ed<=5.0; Ed+=1.0){
    std::string name="amyloid_" + std::to_string((int)Ed) + ".txt"; //variable outfile name
    ofstream outfile; //declaring outfile
	outfile.open(name); //opening outfile
for(rhob=rstart; rhob<=rend; rhob+=rinc){
    
for(c=cstart; c<=cend; c+=cinc){
    j=0;
    vector<double> x;
    x.resize(M);
    srand48(seed);
    
    n = 0.0; //array length counter
    cp = 0.0; //type + counter
    cm = 0.0; //type - counter
    k1 = rhob*c; //+ reaction constant:         
    k2 = (1.000-rhob)*c; //- reaction constant: 
    m = 0.0;
    o = 0.0; //order parameter
    //ktot = k1+k2+k3; //net reaction constant
    t = 0.0; //net time
    x[0] = drand48() >= rhob ? 1.0 : -1.0;
    for (int i=1; i<=N && j<=N; i++) { //loop over array
        R1 = drand48(); //generate first random number
        if(i>=2){
            E = x[i-2] == x[i-1] ? Es : Ed; //determine energy condition 
            k3 = exp(-E); //set decay rate constant
            ktot = k1+k2+k3; //reset total reaction constant
        } else {
            ktot = k1+k2;
        }
        //if between 0 and k1/ktot: event 1; else if between k1/ktot and (k1+k2)/ktot: event 2; else if between (k1+k2)/ktot and 1: event 3
        if (R1<=k1/ktot) {
            x[i] = 1.0; //+ type
        } 
        if (R1<=(k1+k2)/ktot && R1>k1/ktot) {
            x[i] = -1.0; //- type
        }
        if (R1>(k1+k2)/ktot) {
            x.erase(x.begin() + i-1); //erase last element
            i = i-2; //return to previous position
            //outfile<<"erased"<<" "<<i<<" "<<x[i]<<endl;
        }
        
        R2 = drand48(); //generate second random number
        twait = -log(1.0-R2)/ktot; //set wait time for current step
        t += twait; //increment net time
        
        //outfile<<j<<" "<<i<<" "<<x[i]<<endl;
        j++;
    }
    //1: low conc, show grow mostly 50/50 A/B (tune Eaa lower, Ebb lower, Eab higher [higher binding between AB than alone])
   
        for(i=1; i<=N; i++){ //loop over complete array
            if (x[i]==1.0 || x[i]==-1.0){ //determine type
                n++; //increment array length counter
                cp+= x[i]==1.0 ? 1.0 : 0.0; //conditional for type +
                cm+= x[i]==-1.0 ? 1.0 : 0.0; //conditional for type -
                o+= x[i]*x[i+1]; //order parameter increment
                m+= x[i];
            }//if close
        }//array count loop close
    //cout<<n<<" "<<cp<<" "<<cm<<" "<<t<<" "<<n/t<<" "<<o<<" "<<o/(n-1.0)<<endl;
    
    
    outfile<<c<<"\t"<<rhob<<"\t"<<m/n<<"\t"<<n/t<<"\t"<<o/(n-1.0000001)<<endl;
    
    
    /*if(c==cstart){
        outfile<<"{";
    }
    if(c<cend-cinc){
    outfile<<"{"<<c<<", "<<o/(n-1.0)<<"},"<<endl;
    }
    else{
    outfile<<"{"<<c<<", "<<o/(n-1.0)<<"}}"<<endl;
    }*/
    
    
    }//conc loop close
    }//rhob loop close
    }//Edif loop close
} //main close
    
                            
    //expect to have some solubility at which diff binding events become stable and diff c at which same binding events become stable
    //stability condition: 1 component: c*p = k3: unstable dissolves and gets smaller
    //2 comp: at least 4 diff timescales: red binding, blue binding, red diffusion, blue diffusion
    //2 diff stability conditions: 1/2*c=e^-E
    //c*p = k3, c*(1-p) = k3, c*p = k2, c*p = k1