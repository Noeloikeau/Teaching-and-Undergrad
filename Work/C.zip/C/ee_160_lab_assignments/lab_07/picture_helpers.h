int draw_smiley_eyes();
int draw_smiley_nose();