int draw_smiley_eyes() {
  printf (".  .");
  return 4;
}

int draw_smiley_nose() {
  printf ("  |  ");
  return 5;
}

int draw_smiley_mouth() {
  printf ("\\___/");
  return 5;
}

int draw_frowney_eyes() {
  printf ("O  O");
  return 4;
}

int draw_frowney_nose() {
  printf ("  |  ");
  return 5;
}

int draw_frowney_mouth() {
  printf ("/```\\");
  return 5;
}