//Here we want to average all inputs from the user after we track the maximum and minimum inputs. So we should try to flag the inputs and distill them. 
#include <stdio.h>
#include <stdlib.h>

void main() {
    char input=0;
    int max, min;
    int total = 0;
    int counter = 0;
    float average = 0;
    int flag = 0;
    while (1) {
        printf("Enter any amount of numbers you want. Because of the limiations of scanf, use only integers up to 250. Enter 'q' to quit. \n");
        scanf(" %c", &input);
        
        // Decide when to break out of the loop. Do not want to include the 'q' in the calculations
        if (input == 'q') {
            break;
        }
        
        if (counter==0) {
        max = atoi(&input);
        min = atoi(&input);
        }
        else if (input > max) {
            max = atoi(&input);
        }
        else if(input < min) {
            min = atoi(&input);
        }
        counter++;
        total += atoi(&input);
        average = (total/counter);
    }
    
    average = (float)total/(float)counter;
    
    if (input == 'q') {
        printf("You've exited the program because you entered 'q'. \n");
        printf("You average was %f, your maximum was %d, and your minimum was %d.\n", average, (int)max, (int)min);
        flag++;
    }
}