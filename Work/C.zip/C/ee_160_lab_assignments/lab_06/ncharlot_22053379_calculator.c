#include <stdio.h>
void main() {
    float x, y, z;
    char c;
    
    printf("Please enter two numbers: \n");
    scanf("%f %f", &x, &y);
    printf("Please enter a mathematical operator: \n");
    scanf(" %c", &c);
    
    if (c=='+') {
        z=(x+y);
        printf("The sum of both numbers is %f", z);
    }
    else if (c=='-') {
         if (x>y) {
             z=(x-y);
             printf("The difference of both numbers is %f", z);
         }
         else {
             z=(y-x);
             printf("The difference of both numbers is %f", z);
         }
    }
    else if (c=='*') {
        z=(x*y);
        printf("The product of both numbers is %f", z);
    }
    else if (c=='/') {
        z=(x/y);
        printf("The quotient of both numbers is %f", z);
    }
    else if (c =='%')   {
        z = ((int)x%(int)y);
        printf("The remainder of the Euclidean division of both numbers is %d\n", (int)z);
    }
}