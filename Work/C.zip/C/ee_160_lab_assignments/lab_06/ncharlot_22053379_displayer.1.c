#include <stdio.h>

void main() {
    
    printf(" +++++++++++++\n");
    printf(" {   O   O   }");
    printf("\n {     >     }");
    printf("\n {  /`````\\  } ");
    printf("\n");
    printf(" +++++++++++++\n");
    
}
