#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

int main(void) {
    int ref = 0;
    int pre_ref = 0;
    double lat=0;
    double lon=0;
    double pre_lat=0;
    double pre_lon=0;
    double distance;
    char date[25];
    int ride_number=0;
    int offset=0;
    double delta_lat=0;
    double delta_lon=0;
    double ride_dist[1000];
    
    
    FILE *fp;
    fp = fopen("uber.tsv", "r");
    

    while (fscanf(fp, "%d\t%s\t%lf\t%lf", &ref, &date, &lat, &lon) != EOF) {
       
        if (pre_ref != ref) {
            ride_number++;
            offset=(ride_number-1);
            ride_dist[offset] = 0;
        } 
        else {
          delta_lat = (lat - pre_lat);
          delta_lon = (lon - pre_lon);

          distance = sqrt((delta_lat)*(delta_lat) + (delta_lon)*(delta_lon));
          
          ride_dist[offset] = ride_dist[offset] + distance;
        }
      
      pre_ref = ref;
      pre_lat = lat;
      pre_lon = lon;
    }
    
    fp = fopen("rides.txt", "w");
    int i=0;
    for(i=0; i<offset; i++) {
        fprintf(fp, "Ride # %d:  %lf meters \n", i, ride_dist[i]);
    }
return 0;
}