/*   File:  display.c
//   By:    The Awesome Class of EE160
//   Date:	Today :)
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "display.h"

// This program provides the basic foundations to all future game type lab assignments in EE160
int main(void) {
  int i;
  char command;
  int x_position = HORIZONTAL_START;
  int y_position = VERTICAL_START;
  int score=0;
  int high_score=0;
  char player[10];
  char flag;
  
  SETUP_DISPLAY
  clear_screen();
  seed_random_generator();
  
int attacker_x_position, attacker_y_position;
  attacker_x_position = rand() % 36 + 1;
  attacker_y_position = rand() % 17 + 2;

int item_x_position, item_y_position;
  item_x_position = rand() % 36 + 1;
  item_y_position = rand() % 17 + 2;

while (command != QUIT_KEY) { // a do..while loop would have been a nicer fit here; we will talk about the do..while loop later
    clear_screen();
    display_instructions();
    update_position(&x_position, &y_position, command);
    display_position(x_position, y_position);
    display_item(item_x_position, item_y_position);
    
    update_attacker_position(&attacker_x_position, &attacker_y_position, x_position, y_position);
    
if (item_x_position == x_position && item_y_position == y_position) {
        item_x_position = rand() % 36 + 1;
        item_y_position = rand() % 17 + 2; 
        score++;
    }
if (attacker_x_position == x_position && attacker_y_position == y_position) {
    printf("You lost. Press 'q' to quit \n");
}
    redraw_screen(x_position, y_position, item_x_position, item_y_position, attacker_x_position, attacker_y_position); 
    command = getchar(); // you should Google getchar and play around with this function to get comfortable with it
}
if (command == QUIT_KEY) {
    printf("\n");
    high_score = score;
    printf("Enter your name (10 characters or less) \n");
    scanf("%s", player);

  FILE *file_pointer;  
  file_pointer = fopen("high_score.txt", "w");
  fprintf(file_pointer, "=====High Score for %s===== \n", player);
  fprintf(file_pointer, "%d \n", score);
  fclose(file_pointer);
}

  BREAKDOWN_DISPLAY
  return 0;
}

