#include <stdio.h>
int main() {
    srand (time(NULL));
    
    float x = rand() % 20 +1;
    float y = rand() % 20 +2;
    
    printf("%f\n\n", x);
    printf("%f\n\n", y);
    
    return 0;
}
