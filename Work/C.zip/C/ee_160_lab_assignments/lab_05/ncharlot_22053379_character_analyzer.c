#include <stdio.h>
//Here we want to analyze any character input, return the character and describe its type to the user - as long as its not 'q'
void main() {
    char user_input;
    while (user_input != 'q') {
    printf("Enter any character, number, or symbol. \n");
    scanf("%c", &user_input);
        if (user_input>='A' && user_input<='Z') {
        printf("You entered a capital letter. \n");
    }   else if (user_input>='a' && user_input<='z' && user_input!='q') {
        printf("You entered a lowercase letter. \n");
    }   else if (user_input>= '1' && user_input<='9') {
        printf("You entered a number. \n");
    }   else if (user_input!='q') {
        printf("You entered a special character which is not a letter or number. \n");
    }   if (user_input == 'q') {
        printf("You have entered 'q' which is the exit command. Goodbye! \n");
    }
    printf("Would you still like to enter more characters? If not, press 'q' to quit. \n");
    scanf("%c", &user_input);
}
}