//Write a program (UHusername_UHID_number_repeater.c e.g. zhaol_12345678_number_repeater.c) 
//that will allow the user to enter in a number and then the program will repeat the number back to the user. 
//Values 0 thru 10 will be repeated by the same number of times as the number. 
//Values 11 thru 100, will be repeated 15 times. Values greater than 100 will be repeated 20 times. The program will continue until the user enters in 999.

#include <stdio.h>
void main() {
int user_input;
int counter=1;
int counter_2=1;
int counter_3=1;
char flag=0;
while (flag==0) {
 printf("Enter any integer you'd like to repeat:");
 scanf("%d", &user_input);
if (user_input!=999) {
    if (user_input>=1 && user_input<=10) {
        while (counter<=user_input) {
            printf("%d\n", user_input);
            counter++;
        }
        counter=1;
    }   
    else if (user_input>10 && user_input<=100) {
        while (counter_2<=15) {
            printf("%d\n", user_input);
            counter_2++;
        }
        counter_2=1;
    }
    else if (user_input>100) {
        while (counter_3<=20) {
            printf("%d\n", user_input);
            counter_3++;
        }
        counter_3=1;
    } 
} 
else if (user_input == 999) {
    printf("You've exited the program because you entered 999. \n");
    flag++;
    }
}
}
