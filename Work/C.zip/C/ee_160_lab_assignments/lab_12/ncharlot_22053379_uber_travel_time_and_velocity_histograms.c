#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
void main() {
    int id = 0;
    char time[25];
    int t = 0;
    int prev_time = 0;
    int start_time = 0;
    int end_time = 0;
    int ride_time[1000];
    double a;
    double b;
    int rides = 0;
    int previous_id = 0;
    double dist = 0;
    double ride_dist[1000];
    double prev_a = 0;
    double prev_b = 0;
    int hr[24] = {0};
    FILE *file_pointer;
    file_pointer = fopen("uber.tsv", "r");
while (fscanf(file_pointer, "%d\t%s\t%lf\t%lf", &id, &time, &a, &b) != EOF) {
    char* day = strtok(time, "T");
    char* hour = strtok(NULL, ":");
    char* min = strtok(NULL, ":");
    char* sec = strtok(NULL, "+");
    int hrs = atoi(hour);
    t = atoi(hour)*3600 + atoi(min)*60 + atoi(sec);
    switch (hrs) {
        case 0: hr[0]++;
        break;
        case 1: hr[1]++;
        break;
        case 2: hr[2]++;
        break;
        case 3: hr[3]++;
        break;
        case 4: hr[4]++;
        break;
        case 5: hr[5]++;
        break;
        case 6: hr[6]++;
        break;
        case 7: hr[7]++;
        break;
        case 8: hr[8]++;
        break;
        case 9: hr[9]++;
        break;
        case 10: hr[10]++;
        break;
        case 11: hr[11]++;
        break;
        case 12: hr[12]++;
        break;
        case 13: hr[13]++;
        break;
        case 14: hr[14]++;
        break;
        case 15: hr[15]++;
        break;
        case 16: hr[16]++;
        break;
        case 17: hr[17]++;
        break;
        case 18: hr[18]++;
        break;
        case 19: hr[19]++;
        break;
        case 20: hr[20]++;
        break;
        case 21: hr[21]++;
        break;
        case 22: hr[22]++;
        break;
        case 23: hr[23]++;
        break;
    }
}
printf("===Histogram of Ride Frequency Per Hour===\n[Hour] [#Occurances]\n");
int x=0;
for (x=0; x<24; x++) {
    printf("[%d] [%d]\n", x, hr[x]);
}
//in the last lab we got velocities, output in rides.txt
//so lets total the velocities, get min, get max
//then create intervals according to frequency 
//such that the intervals are partitioned according to max/10 
//our max is ~40 (known from last lab's sorted text file), so the common factor is 4
//the sequence of partitions is simply checking velocity against an n-multiple of our common factor
int max=45,min=0;
double velocity;
int bin[11]={0};
int ride_id=0;
int factor=(max/10);

file_pointer = fopen("rides.txt", "r");
while (fscanf(file_pointer, "%d\t%lf", &ride_id, &velocity) != EOF) {
if (velocity>=0&&velocity<factor) { bin[0]++;}
else if (velocity>=factor&&velocity<(2*factor)) { bin[1]++;}
else if (velocity>=(2*factor)&&velocity<(3*factor)) { bin[2]++;}
else if (velocity>=(3*factor)&&velocity<(4*factor)) { bin[3]++;}
else if (velocity>=(4*factor)&&velocity<(5*factor)) { bin[4]++;}
else if (velocity>=(5*factor)&&velocity<(6*factor)) { bin[5]++;}
else if (velocity>=(6*factor)&&velocity<(7*factor)) { bin[6]++;}
else if (velocity>=(7*factor)&&velocity<(8*factor)) { bin[7]++;}
else if (velocity>=(8*factor)&&velocity<(9*factor)) { bin[8]++;}
else if (velocity>=(9*factor)&&velocity<(10*factor)) { bin[9]++;}
else {bin[10]++;}
    }
printf("===Histogram of Velocity Frequency Distribution===\n");
printf("This histogram includes less #Occurances because a max of 1000 velocity values were scanned.\n");
printf("[Velocity] [#Occurances]\n");
x=0;
for (x=0; x<11; x++) {
    printf("[%d to %d]  [%d]\n", (factor*x), factor*(x+1), bin[x]);
}

}
