void clear_screen () {
  int i;
  for (i=1; i <= SCREEN_HEIGHT; i++) {
    printf ("\n");
  }
}

void seed_random_generator () {
  srand(time(NULL)); // This is needed so the random generator function, rand(), generates different random numbers each time the program starts
}

void display_position(int x_position, int y_position) {
  printf("Current Position: x: %d, y: %d\n", x_position, y_position);
}

void display_item(int item_x_position, int item_y_position) {
    printf("The item position is %d on x-axis and %d on y-axis. \n", item_x_position, item_y_position);
}

void display_instructions() {
  printf("Press 'w' to go UP, 's' to go DOWN, 'a' to go LEFT, 'd' to go RIGHT, and 'q' to quit\n");
}

void update_position(int* x_position_pointer, int* y_position_pointer, char command) {
  switch (command) { // we will be learning about the switch statement later (but you can Google it for now)
    case UP_KEY:
    if (*y_position_pointer>2) {
      update_y_position(y_position_pointer, -1);
    }
      break;
    case DOWN_KEY:
    if (*y_position_pointer<(SCREEN_HEIGHT-1)) {
      update_y_position(y_position_pointer, 1);
    }
      break;
    case LEFT_KEY:
    if (*x_position_pointer>1) {
      update_x_position(x_position_pointer, -1);
    } 
      break;
    case RIGHT_KEY:
    if (*x_position_pointer<(SCREEN_WIDTH-3)) {
      update_x_position(x_position_pointer, 1);
    }
      break;
  }
}

void update_y_position(int* y_position_pointer, int delta) {
  *y_position_pointer += delta;
  if (*y_position_pointer <= 1){
      *y_position_pointer = 19;
  }
  if (*y_position_pointer >= 20) {
      *y_position_pointer = 2;
  }
}

void update_x_position(int* x_position_pointer, int delta) {
    *x_position_pointer += delta; 
    if (*x_position_pointer <= 1) {
        *x_position_pointer = 36;
    }  
    if (*x_position_pointer >= 37) {
        *x_position_pointer = 1;
    }
}

void update_attacker_position(int* attacker_x_position, int* attacker_y_position, int x_position, int y_position) {
    if (*attacker_x_position < x_position) {
        *attacker_x_position += 1;
    } else if (*attacker_x_position > x_position) {
        *attacker_x_position -= 1;
    } else if (*attacker_y_position < y_position) {
        *attacker_y_position += 1;
    } else {
        *attacker_y_position -= 1;
    }
    
}

void redraw_screen(int x_position, int y_position, int item_x_position, int item_y_position, int attacker_x_position, int attacker_y_position) {
  int current_screen_row = 1;
  int current_screen_column = 1;
  while (current_screen_row <= SCREEN_HEIGHT) {
    draw_horizontal_borders(current_screen_row);
//now use if statement logic gates to distill attackers position
    if (not_top_or_bottom_row(current_screen_row)) {
    }
      if (current_screen_row == item_y_position || current_screen_row == y_position) {
      }
       if (current_screen_row == item_y_position && current_screen_row == y_position) {
        draw_row_with_token_and_item(x_position, item_x_position);
        } else if (current_screen_row == attacker_y_position && current_screen_row == y_position) {
        draw_row_with_attacker_and_token(attacker_x_position, x_position);
        } else if (current_screen_row == attacker_y_position && current_screen_row == item_y_position) {
            draw_row_with_attacker_and_item(attacker_x_position, item_x_position);
        } else if (current_screen_row == y_position) {
            draw_row_with_token(x_position);
        } else if (current_screen_row == item_y_position) {
            draw_row_with_item(item_x_position);
        } else if (current_screen_row == attacker_y_position) {
            draw_row_with_attacker(attacker_x_position);
        }

      else {
        draw_empty_row();
      }
      current_screen_row++;  
    }
}

void draw_row_with_item(int item_x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  remaining_line_width -= draw_empty_spaces(item_x_position);
  remaining_line_width -= print_item();
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}

void draw_row_with_token(int x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  remaining_line_width -= draw_empty_spaces(x_position);
  remaining_line_width -= print_token();
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}

void draw_row_with_token_and_item(int item_x_position, int x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  if (item_x_position < x_position) {
     remaining_line_width -= draw_empty_spaces(item_x_position);
     remaining_line_width -= print_token();
     remaining_line_width -= draw_empty_spaces(x_position - item_x_position - 1);
     remaining_line_width -= print_item();
  }
  else {
    remaining_line_width -= draw_empty_spaces(x_position);
    remaining_line_width -= print_item();
    remaining_line_width -= draw_empty_spaces(item_x_position - x_position - 1);
    remaining_line_width -= print_token();
  }
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}
int print_attacker() {
    printf("%c", ATTACKER);
    return 1;
}

int print_token() {
  printf ("%c", TOKEN);
  return 1;
}

int print_item() {
  printf ("%c", ITEM);
  return 1;
}

void draw_empty_row() {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}

int draw_empty_spaces(int number_of_empty_spaces) {
  int i;
  for(i=1; i <= number_of_empty_spaces; i++) {
    printf("%c", EMPTY_SPACE);
  }
  return number_of_empty_spaces;
}

void draw_horizontal_borders(int current_screen_row) {
  int i;  
  if ((current_screen_row == 1) || (current_screen_row == SCREEN_HEIGHT)) {
    for (i=1; i <= SCREEN_WIDTH; i++) {
      printf ("%c", HORIZONTAL_BORDER);
    }
    printf ("\n");
  }
}

int not_top_or_bottom_row(int current_screen_row) {
  return ((current_screen_row != 1) && (current_screen_row != SCREEN_HEIGHT));
}

int draw_left_border() {
  printf("%c", VERTICAL_BORDER);  
  return 1;
}

void draw_right_border() {
  printf("%c\n", VERTICAL_BORDER);
}

//Attacker code
void draw_row_with_attacker(int attacker_x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  remaining_line_width -= draw_empty_spaces(attacker_x_position);
  remaining_line_width -= print_attacker();
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}
void draw_row_with_attacker_and_token(int attacker_x_position, int x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  if (attacker_x_position < x_position) {
     remaining_line_width -= draw_empty_spaces(attacker_x_position);
     remaining_line_width -= print_token();
     remaining_line_width -= draw_empty_spaces(x_position - attacker_x_position - 1);
     remaining_line_width -= print_attacker();
  }
  else {
    remaining_line_width -= draw_empty_spaces(x_position);
    remaining_line_width -= print_attacker();
    remaining_line_width -= draw_empty_spaces(attacker_x_position - x_position - 1);
    remaining_line_width -= print_token();
  }
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}

void draw_row_with_attacker_and_item(int item_x_position, int attacker_x_position) {
  int remaining_line_width = SCREEN_WIDTH;
  remaining_line_width -= draw_left_border();
  if (item_x_position < attacker_x_position) {
     remaining_line_width -= draw_empty_spaces(item_x_position);
     remaining_line_width -= print_attacker();
     remaining_line_width -= draw_empty_spaces(attacker_x_position - item_x_position - 1);
     remaining_line_width -= print_item();
  }
  else {
    remaining_line_width -= draw_empty_spaces(attacker_x_position);
    remaining_line_width -= print_item();
    remaining_line_width -= draw_empty_spaces(item_x_position - attacker_x_position - 1);
    remaining_line_width -= print_attacker();
  }
  draw_empty_spaces(REMAINING_LINE_WIDTH_WITHOUT_RIGHT_BORDER);
  draw_right_border();
}
