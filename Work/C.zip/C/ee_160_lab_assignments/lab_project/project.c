#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
char l1_departure[255]; //san_fran_cisco is 13 characters
char l1_arrival[3][255]; //3 cities, each less than 20 characters
int l1_distance[3];
int n=0, m=0, tot=0;
FILE* fp1,* fp2,* fp3;
fp1 = fopen("leg1.txt", "r");
fp2 = fopen("leg2.txt", "r");
fp3 = fopen("leg3.txt", "r");
for (n=0;n<3;n++) {
    fscanf(fp1, "%s\t%s\t%d", l1_departure, &(l1_arrival[n]), &(l1_distance[n]));
}
int combo_distances[9];
char l2_departure[9][20]; //9 transit combos, to cities less than 20 characters long
char l2_arrival[9][20]; 
int l2_distance[9];
for (n=0;n<9;n++) {
        fscanf(fp2, "%s\t%s\t%d", &(l2_departure[n]), &(l2_arrival[n]), &(l2_distance[n]));
        for (m=0;m<3;m++) {
            if (strcmp(l1_arrival[m],l2_departure[n])==0) {
                combo_distances[n]=(l2_distance[n]+l1_distance[m]);
            }
        }
    tot=0;
}
char l3_departure[3][255];
char l3_arrival[255];
int l3_distance[3];
for (m=0;m<3;m++) {
        fscanf(fp3, "%s\t%s\t%d", &(l3_departure[m]), l3_arrival, &(l3_distance[m]));
        for (n=0;n<9;n++) {
            if (strcmp(l3_departure[m], l2_arrival[n])==0) {
                combo_distances[m]=(l2_distance[n]+l3_distance[m]);
            }
        }
    tot=0;
}
int max = 100000;
int ind = 0;
for (n=0;n<9;++n) {
   if (combo_distances[n]<max) {
       max = combo_distances[n];
       ind = n;
   }
}
int compare( const void* a, const void* b) {
   int int_a = * ( (int*) a );
   int int_b = * ( (int*) b );
   return (int_a > int_b) - (int_a < int_b);
}
qsort(combo_distances, 9, sizeof(int), compare);
for (n=0;n<9;n++) {
printf("Cost of shortest travel: %d\n", combo_distances[n]);
}
printf("Shortest distance: sanfrancisco to %s to %s to new_york", l2_departure[ind], l2_arrival[ind]);

return 0;
}








//use strcmp


/*while(fscanf(fp, "%s\t%s\t%d", &l2_departure, &l2_arrival, &l2_distance)!=EOF) {
    for (m=0;m<9;m++) {
        for (n=0;n<3;n++) {
                if (l1_arrival[n]=="las_vegas") {
                    l2_distance[m]+=l1_distance[n]; //total transit distance
                    printf("%d\n",l2_distance[m]);
                    printf("%d\n",l2_distance[n]);
                    //getchar();
                }
               else if (l1_arrival[n]=="tucson") {
                    l2_distance[m]+=l1_distance[n]; //total transit distance
                    printf("%d\n",l2_distance[m]);
                    printf("%d\n",l2_distance[n]);
                    //getchar();
                }
               else if (l1_arrival[n]=="salt_lake_city") {
                    l2_distance[m]+=l1_distance[n]; //total transit distance
                    printf("%d\n",l2_distance[m]);
                    printf("%d\n",l2_distance[n]);
                    //getchar();
                }
        }
    }
}*/
 
/*char l3_departure[3][20];
char l3_arrival[8];
int l3_distance[9];
fscanf(fp, "%s\t%s\t%d", &l3_departure, &l3_arrival, &l3_distance); 
switch (l2_departure) {
        case "chicago": 
        for (n=0;n<9;n++) {
                if (l2_arrival[n]=="nashville") {
                    l2_distance[n]+=l3_distance; //total transit distance
                }
        }
        break;
        case "nashville": 
        for (n=0;n<9;n++) { 
                if (l2_arrival[n]=="nashville") {
                    l2_distance[n]+=l3_distance; //total transit distance
                }
        }
        break;
        case "indianapolis": 
        for (n=0;n<9;n++) {
        if (l2_arrival[n]=="indianapolis") {
                    l2_distance[n]+=l3_distance; //total transit distance
                }
        }
        break;
    }
int compare( const void* a, const void* b) {
   int int_a = * ( (int*) a );
   int int_b = * ( (int*) b );
   return (int_a > int_b) - (int_a < int_b);
}
qsort(l2_distance, 9, sizeof(int), compare);
int copy[9];
memcpy(copy, l2_distance, 10);
printf("%d", copy);*/

