//I completed this lab with values much, much smaller for my velocities. I redid it and got larger values, which are easier to work with
//that is the code here
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
void main() {
    int id = 0;
    char time[25];
    int t = 0;
    int prev_time = 0;
    int start_time = 0;
    int end_time = 0;
    int ride_time[1000];
    double a;
    double b;
    int rides = 0;
    int previous_id = 0;
    double dist = 0;
    double ride_dist[1000];
    double prev_a = 0;
    double prev_b = 0;
    FILE *file_pointer;
    file_pointer = fopen("uber.tsv", "r");
while (fscanf(file_pointer, "%d\t%s\t%lf\t%lf", &id, &time, &a, &b) != EOF) {
    char* day = strtok(time, "T");
    char* hour = strtok(NULL, ":");
    char* min = strtok(NULL, ":");
    char* sec = strtok(NULL, "+");
    t = atoi(hour)*3600 + atoi(min)*60 + atoi(sec);
        if (previous_id != id) {
            rides++;
            ride_dist[rides-1] = 0;
            if (rides > 1) {
                ride_time[rides - 2] = end_time - start_time;
            }
            start_time = t;
        } else {
          double delta = (a - prev_a);
          double deltb = (b - prev_a);
          end_time = t;
          dist = sqrt((delta)*(delta) + (deltb)*(deltb));
          ride_dist[rides - 1] = ride_dist[rides - 1] + dist;
        }
      previous_id = id;
      prev_a = a;
      prev_time = t;
    }
printf("Outputting unsorted velocities to 'rides.txt'. The first column is the ride number, the second is the velocity. \n");
    file_pointer = fopen("rides.txt", "w");
double velocit[1000];
    int n = 0;
    for(n = 0; n < rides; n++) {
        velocit[n] = ride_dist[n] / (double)ride_time[n];
        fprintf(file_pointer, "%d  %.15lf \n", n + 1, velocit[n]); 
    }
    //read in unsorted file
printf("Now the file must be sorted, so make sure 'rides.txt' is closed.\nPress enter to generate a sorted file (multiple times if required).\n");
getchar();
    double velocity[1000];
    int ride_id[1000];
    int i,j;
    int temp_id;
    double temp_v;
file_pointer = fopen("rides.txt", "r");
while (fscanf(file_pointer, "%d\t%lf", &ride_id, &velocity) != EOF) {
    for (i = 0; i < 1000; i++) {
	for (j = 0; j < 1000 - i - 1; j++) {
		if (velocity[j] > velocity[j+1])
		{// Swap velocity[j] with velocity[j+1]
			temp_v = velocity[j];
			velocity[j] = velocity[j+1];
			velocity[j+1] = temp_v;
			// Swap ride_id[j] with ride_id[j+1]
			temp_id = ride_id[j];
			ride_id[j] = ride_id[j+1];
			ride_id[j+1] = temp_id;
		                                           }
	                                           }
                                          }
    
    }
file_pointer = fopen("rides.txt", "w");
j = 0;
for (j=0; j<1000; j++) {
    fprintf(file_pointer, "%d  %.15lf \n", ride_id[j+1], velocity[j+1]);
}
printf("rides.txt has been sorted! The first few lines are zeroes for some ungodly reason, but its correctly sorted. \n");
}