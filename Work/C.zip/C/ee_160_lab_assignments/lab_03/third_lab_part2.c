#include <math.h>
#include <stdio.h>
void main () {
    float first_number;
    float second_number;
    printf("Enter two values:");
    scanf("%f" "%f", &first_number, &second_number);
    if (first_number == second_number || second_number == first_number) {
    printf("The values are equal! \n");
    } 
    else if (first_number > second_number) {
        printf("The first number is greater than the second value by %f \n", first_number - second_number);
    }
    else if(second_number > first_number) {
        printf("The second value is greater than the first value by %f /n", second_number - first_number);
        }
        
}