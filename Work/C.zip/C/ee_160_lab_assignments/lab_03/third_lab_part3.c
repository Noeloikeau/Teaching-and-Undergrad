#include <stdio.h>
#include <math.h>
void main (){
char user_input;
printf("Enter anything on your keyboard except a number:");
scanf("%c", &user_input);
if (user_input >= 'A' && user_input <= 'Z') {
    printf("You entered %c and it is uppercase. \n", user_input);
} else if (user_input >= 'a' && user_input <= 'z') {
    printf("You entered %c and it is lowercase \n", user_input);
} else {
    printf("You didn't do what we wanted. We are displeased. \n");
    }
}