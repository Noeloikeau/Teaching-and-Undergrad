#include <stdio.h>
#include <math.h>

// I changed some of the formating for readability and to find the compile error

void main ()
{
    double user_input;
    
    printf("Feed me with numbers by entering one into me slowly:");
    scanf("%lf", &user_input);
    
    if (user_input <= 0)
    {
        printf("You put %f into me... it was negative, does that mean you're taking things out? \n", user_input);
    }
    else if (user_input>0 && user_input<=100)
    {
        printf("You put %f into me, and it is a valid exam score! \n", user_input);
    }
    // The 'else' statement without an if is a catch-all and does not need any conditions
    //else (user_input>100)
    else
    {
        printf("You entered %f and it is an invalid exam score! \n", user_input);
    }
}