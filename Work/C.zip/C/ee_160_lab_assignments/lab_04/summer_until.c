#include <stdio.h>
#include <string.h>
void main() {
    
    /* I'm not sure about your logic here. 
    
    You declare and set a char* ptr1 to "stop", then declare a 0 length char pointer array. I don't think this is doing what you were expecting.
    If you want, I can go over points with you more during lab next week.
    
    */
    float input, output=0; // Don't use uninitialized variables!
    char *ptr1 = "stop";
    char* arr[0];
    arr[0] = ptr1;
    printf("This program will take any amount of distinct numbers you choose and sum them. To stop entering, simply type: 'stop' without quotes. \n");
    scanf("%f" "[%s]", &input, &(arr[0]));
    while (input < strlen(arr[0])) {
        scanf("%f", &input);
        output += input; 
        if (input == strlen(arr[0])) {
    printf("You entered stop! The sum of each number is %f", output);
        }
        }
}
    
    