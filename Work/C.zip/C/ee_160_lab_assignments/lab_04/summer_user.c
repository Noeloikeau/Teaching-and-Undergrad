#include <stdio.h>
//We want to specify the amount of unique decimal numbers the user wishes to enter. Then sum them and warn the user at the penultimate decimal//
void main() {
    int user_specification, counter;
    float input, output;
    printf("Specify the amount of unique decimal numbers you wish to sum: ");
    scanf("%d", &user_specification);
    counter=1;
    while (counter<=user_specification) {
        printf("Please enter %d total unique decimal numbers: ", user_specification);
        scanf("%f", &input);
        if (counter == user_specification - 1) 
        {
            printf("You only need to enter one more number! \n");
        }
        counter = counter++;
        output += input;
        }
        printf("The sum of the entered values is %f \n", output);
    }