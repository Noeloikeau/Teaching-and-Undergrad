#include <stdio.h>
main() {
    float input, total;
    char continue_flag = 'y';
    
    total = 0;
    
    while (continue_flag == 'y') {
    
    printf("Please enter a decimal number: ");
    scanf ("%f", &input);
    printf("Do you stil want to enter a decimal number? Enter y for yes and n for no. \n");
    scanf(" %c", &continue_flag);
    total += input;
    }
    
    
    printf("The sum of your decimal numbers is %f \n", total);
    
}