#include <stdio.h>
void main()
{
    int counter=1;
    float input, output;
    output = 0;
    while (counter<=10) {
        printf("Enter 10 decimal numbers:");
        scanf("%f", &input);
        if (counter == 9) {
            printf("That was the penultimate decimal number necessary! \n");
        }
    counter = counter++;    
    output +=input;       
    }
    printf("The sum of all decimal numbers is %f \n", output);
}

    