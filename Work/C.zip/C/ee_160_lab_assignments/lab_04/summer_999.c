#include <stdio.h>
// We want the user to input values until they enter 999. Then, we want the output to be the sum of all values which weren't 999//
void main() {
float input, output;
int counter = 1;
while (input != 999) {
    printf("Continue to enter decimal values until you wish to stop, at which point enter 999:  ");
    scanf("%f", &input);
    output +=input;
    if (input==999) {
        output=output-999;
        printf("Sum of decimal numbers is %f", output);
    }
}
}