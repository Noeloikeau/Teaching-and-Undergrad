#include <stdio.h>
#include <stdlib.h>
int main(void) {
    char arr[5];
    int i=0;
    int j=0;
    printf("Enter a positive integer with a maximum of 5 digits and this program will count from 0 until the entered number. \n");
    printf("Enter 'q' to quit this program, alternatively. \n");
    printf("Enter: \n");
do {
    scanf(" %s", &arr);
    i = atoi (arr);
    if (arr[0]=='q') {
    printf("Quitting... \n"); }
    else if (i!=0) {
    for (j=0; j<=i; j++) {
        printf("Counting: %d \n", j); }
    } else {
      printf("Please enter a valid integer, or the letter 'q'. \n");
    }
} while (arr[0]!='q');

}
