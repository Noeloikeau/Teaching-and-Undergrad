//Here we want to write a program that takes in 2 numbers (x & y) and calculates z=−x+x2−4y*2y
#include <stdio.h>
void main() {
    int x=0;
    int y=0;
    printf("Enter two numbers seperated by a space: \n");
    scanf("%i %i", &x, &y);
    int z;
    z=((x*x-x)-(y*y*8));
    printf("%i", z);
}
        
    