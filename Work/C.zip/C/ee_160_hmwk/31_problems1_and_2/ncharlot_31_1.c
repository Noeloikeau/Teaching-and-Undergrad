#include <stdio.h>

int main(){

    printf("Enter the number of columns:\n");
    int x; 
    scanf("%d", &x);
    printf("Enter the number of rows:\n");
    int y; 
    scanf("%d", &y);

    int r[x][y];
    int a;
    int b;

        for (a=0; a<x; a++){
            for (b=0; b<y; b++){
    printf("Enter a value for [%d][%d]\n", a, b);
    scanf("%d",&r[a][b]);
        }
    }
int i=0,j=0;
for (i=0; i<x; i++){
    printf("\n");
            for (j=0; j<y; j++){
                printf("[%d][%d]: %d \t", i,j,r[i][j]);
}
}
}