#include <stdio.h>
int main(void) {
    //read in a 12x15 matrix
char o[12][15];
char r[12][15];
char x;
char y;
char i=0,j=0;
FILE* fp;
fp = fopen("ncharlot_31_2_input.txt", "r");

for (i=0; i<12;i++) {
    for(j=0;j<15;j++) {
        fscanf(fp, " %c", &r[i][j]);
        o[i][j]=r[i][j]; //copy r to o
    }
}
for (i=0; i<12;i++) {
    for(j=0;j<15;j++) {
        if (r[i][j]=='X') {
            o[i-1][j-1]='X';
            o[i-1][j]='X';
            o[i-1][j+1]='X';
            o[i][j-1]='X';
            //o[i][j]='X'; redundant 
            o[i][j+1]='X';
            o[i+1][j-1]='X';
            o[i+1][j]='X';
            o[i+1][j+1]='X';
            
        }
    }
}
for (i=0; i<12;i++) {
    for(j=0;j<15;j++) {
        printf("%c", o[i][j]);
    }
    printf("\n");
}
return 0;
}
    