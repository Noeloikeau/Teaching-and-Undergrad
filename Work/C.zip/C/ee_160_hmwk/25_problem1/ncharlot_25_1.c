#include <stdio.h>
int main (void) {
    printf("Enter a letter, either upper or lower case. You will be informed if you won, or if the input was invalid. \n");
    char c;
    int c_position = 0;
    scanf(" %c", &c);
    printf("Value of c = %d \n", c);
    if (c>=65 && c<=90) {
        c_position = 1;
    } else if (c>=97 && c<=122) {
        c_position = 2;
    }
    
switch (c_position) {
    case 2: 
        if (c == 'q' || c == 'r') {
            printf("Your lowercase letter was a winner! \n");
        } else {
            printf("Your lowercase letter was not a winner.. \n");
        }
    break;
    case 1:
        if (c =='I' || c=='O' || c=='A' || c=='E' || c=='U') {
            printf("Your uppercase letter was a winner! \n");
        } else {
            printf("Your uppercase letter was not a winner.. \n");
        }
    break;
    default: 
    printf("You entered an invalid character. \n");
    break;
    }
}
