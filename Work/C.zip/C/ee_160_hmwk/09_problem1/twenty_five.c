//We simply want to raise an input via an increment power function//
#include <stdio.h>
#include <math.h>
void main() {
    float input;
    float output = 1;
    int counter = 0;
    printf("Enter a value: ");
    scanf("%f", &input);
    while (counter < 25) {
        output = output * input; 
        counter++;
        printf("Your original input multiplied by itself %i times equals %f \n", counter, output);
        if (counter == 25) { 
            printf("Your original input raised to the 25th power equals %f", output);
    } 

    }
}
    