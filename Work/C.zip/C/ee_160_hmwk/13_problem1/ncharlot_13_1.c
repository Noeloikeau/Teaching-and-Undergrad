#include <stdio.h>

int main() {
  int integer1 = 3;
  int integer2 = 4;
  float decimal = 4;
  
  float answer = (integer1/decimal);
  
  // both statements should print out correct answer to 3/4
  printf("int / float: %f\n", answer);
  printf("int / int: %f\n", integer1/integer2);
  
  // you need to figure out what is the mod operator and how to use the mod operator
  // the output should be 1
  printf("using the %% operator: %d\n", (int)decimal % integer1);
  
  return 0;
}
    