#include <stdio.h>
void main()
{
    int first_number;
    float second_number;
    char special_letter;

    first_number = 3;
    second_number = 5;
    special_letter = '/';
    
    printf ("'////' \n");
    printf ("//The first number is %d// \n", first_number);
    printf ("//The second number is %f// \n", second_number);
    printf ("//The special character is \'%c\'// \n", special_letter);
}