// I couldn't get the template to work so I simply wrote an algorithm in here//
Begin:
    Request a numerical input from the user. 
    Check the input against the given parameters. Namely, the input must be 100<=x<=199.
    This produces three cases: 
        If (input <100), then output "the number is not magic".
        If (100 < input < 200) then output "the number is magic".
        If (input > 199) then output "the number is too magic".
End