#include <stdio.h>
#include <math.h>
int main ()
{
int variable_x = 10;
char letter_a = 'a';
float pi = 3.14;
double extra_digits = 1.2345;
printf("I have initialized the variable integer X to be %d \n", variable_x);
printf("I have initialized the letter variable to be %c \n", letter_a);
printf("I have initialized the float variable Pi to be %f \n", pi);
printf("I have initialized the double variable to be %f \n", extra_digits);
return 0; 
}