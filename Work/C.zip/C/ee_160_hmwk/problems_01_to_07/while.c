#include <stdio.h>

main() {
  int counter;

  counter = 1;
  while (counter <= 3, counter++) {
    printf ("Hip, hip, hooray!\n");
    if (counter == 3) {
      printf ("That was the last cheer. :(\n");
    }
  }
}