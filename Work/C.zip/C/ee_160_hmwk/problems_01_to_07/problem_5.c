#include <stdio.h>
#include <math.h>
void main(){
long int user_integer;
char user_character;
float user_decimal;
printf("Enter a character, a decimal, and an integer in that order:");
scanf("%c" "%f" "%6i", &user_character, &user_decimal, &user_integer);
printf("Character: %c \n", user_character);
printf("Decimal: %f \n", user_decimal);
printf("Integer: %i \n", user_integer);
} 
