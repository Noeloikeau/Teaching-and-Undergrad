#include <stdio.h>
#include <math.h>
int main ()
{
double variable_x = 1.2345;
//truncation example
printf("%f \n", (double)((int)(variable_x*100))/100);
//padding in back
printf("Zero padding in back: %.5f, %.6f, %.7f \n", variable_x, variable_x, variable_x);
//padding in front
printf("%08.3f \n", variable_x);
}