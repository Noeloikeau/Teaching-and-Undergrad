#include <stdio.h>
void main() {
    float number;
//If 100 <= number <= 199 then it is magical.//
    printf ("Enter a magical number: ");
    scanf ("%f", &number);
    if (number < 100) {
        printf("Your number isn't very magical ): \n");
    } else if (number >= 100 && number <= 199) {
        printf("Your number is very magical! \n");
    } else {
        printf("Your number is too magical ): \n");
    }
}