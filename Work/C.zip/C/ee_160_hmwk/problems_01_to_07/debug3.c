#include <stdio.h>

void main() 
{
    int first_number;
    float second_number;
    char special_letter;

    first_number = 3;
    second_number = 5;
    special_letter = '/';
    
    printf ("'////'");
    printf ("//The first number is %f//", first_number);
    printf ("//The second number is %d//", second_number);
    printf ("//The special character is \"%c\"//", special_letter);
}