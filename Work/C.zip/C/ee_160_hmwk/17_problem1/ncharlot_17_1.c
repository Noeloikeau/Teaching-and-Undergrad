#include "ncharlot_17_1_constants.h"
#include <stdio.h>
//I included the printf functions as well as the area calculations in the header file (within each individual macro)
float x=0;

int main() {
    
    printf("Enter a length: ");
    scanf("%f", &x);
    
    CIRCLE_CIRCUMFERENCE(x)
  
    CIRCLE_AREA(x)
  
    SQUARE_AREA(x)
    
    return 0;
}
    
