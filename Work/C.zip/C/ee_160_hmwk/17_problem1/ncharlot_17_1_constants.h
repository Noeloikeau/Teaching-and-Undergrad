#define PIE (3.14)
#define CIRCLE_CIRCUMFERENCE(x) printf("The circumference of the circle is: %f \n", ((2*PIE)*(x)));
#define SQUARE_AREA(x) printf("The area of the square is: %f \n", ((x)*(x)));
#define CIRCLE_AREA(x) printf("The area of the circle is: %f \n", ((x)*(x))*PIE);