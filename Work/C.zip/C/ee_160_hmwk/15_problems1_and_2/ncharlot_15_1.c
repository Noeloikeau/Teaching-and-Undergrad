#include <stdio.h>

int main() {
  int number1;
  int number2;
  
  printf("Please enter in the first number:\n");
  scanf("%d", &number1);
  printf("Please enter in the second number:\n");
  scanf("%d", &number2);

  int add(int number1, int number2) {
      int sum = number1+number2;
      return sum;
      
  }

  printf ("The sum of your two numbers is: %d\n", add(number1, number2));
  
  return 0;
}