void add_now(int* number1, int* number2);
void add_now(int* number1, int* number2) {
    ++*number1;
    ++*number2;
}
#include <stdio.h>
int main() {
  int number1;
  int number2;
  
  printf("Please enter in the first number %d:\n", &number1);
  /*scanf("%d", &number1);
  printf("Please enter in the second number:\n");
  scanf("%d", &number2);

  add_now(&number1, &number2);
  printf("The first number is now: %d\n", number1);
  printf("The second number is now: %d\n", number2);
  printf("easy way: %d", ++number1);
  printf("easy way: %d", ++number2);
  return 0; */  
}

    