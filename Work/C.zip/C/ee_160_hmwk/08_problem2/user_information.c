#include <stdio.h>
void main() {
    int counter;
    int age;
    int gender;
    float GPA;
    printf("Enter your age please: \n");
    scanf("%i", &age);
    if (age < 25) {
        printf("You have a bright future ahead of you! \n");
    } else {
        printf("You must have years of wisdom you can pass on. \n");
          }
    
    printf("Please enter your gender. Enter only '0' for female or '1' for male: \n");
    scanf("%i", &gender);    
    if (gender == 0) {
        printf("Females rock! \n");
    } 
    if (gender ==1) {
        printf("Males rock! \n");
    }

    printf("What's your GPA? \n");
    scanf("%f", &GPA);
    if (GPA >= 0) {
        if (GPA <= 4) {
            printf("There's too much emphasis on this number anyway. \n");
        } else if (GPA >=0) {printf("Your GPA is out of this world! \n");
        }   
    } 
    else {
        printf("Your GPA is unbelievable. \n");
    }
}