#include <stdio.h>
void main() {
    char word[10], reverse[10], i, j, temp;
    
    printf("Please enter a word (10 lowercase letters or less) you'd like alphabetically sorted: \n");
    scanf("%s", &word[i]);
    for (i=0; i<10; ++i) {
        for (j=i; j<10; ++j) {
            if (word[i] > word[j]) {
                temp = word[i];
                word[i] = word[j];
                word [j] = temp;
            }
        }
    }
printf("Sorted array: \n");
for (j=0; j<10; ++j) 
{
          printf("%c",word[j]);
                                    }
}
for(i = 0, j = 9; j >= 0; i++, j--)
    reverse[i] = word[j];
    reverse[i]= '\0';