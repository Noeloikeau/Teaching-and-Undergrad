#include <stdio.h>
int main() {
float numbers[10]; 
int i; 
printf("This program takes 10 float numbers and repeats them to the user.\n\n");
printf("enter 10 numbers:(press enter after each float)\n");
for(i=0;i<10;i++) {
scanf("%f",&numbers[i]); 
}
printf("In order, here are the numbers you entered:"); 
for (i=0; i<10; i++) {
printf("\n %f\n", numbers[i]);
}
}