#include <stdio.h>
//We want to change the program to accept any account type//
main() {
  float account_balance;
  char account_type;
  printf ("c = checking, s = saving \n");
  printf ("Please enter the account type:\n");
  scanf ("%c", &account_type);

  if (account_type=='s' || account_type=='c')  {
  printf ("Please enter the account balance: ");
  scanf ("%f", &account_balance);
  if (account_type == 's') {
    if (account_balance < 1000) {
      printf ("A minimum balance fee needs to be charged to this account.\n");
    } else {
      printf ("A minimum balance fee does not need to be charged to this account.\n");
    }
  } else if (account_type == 'c') {
    if (account_balance < 500) {
      printf ("A minimum balance fee needs to be charged to this account.\n");
    } else {
      printf ("A minimum balance fee does not need to be charged to this account.\n");
    }
  }
} else {
    printf("You didn't enter the right account type. Please try again.");
}  
}