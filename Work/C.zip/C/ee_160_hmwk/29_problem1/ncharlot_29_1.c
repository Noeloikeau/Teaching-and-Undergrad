
#include <stdio.h>
#define FIZZ printf("Fizz");
#define BUZZ printf("Buzz");
int main () {
  int number=0;
  int i=0, j=0;
  printf("Enter a positive integer to count: \n");
  scanf("%d", &number);
    for (i = 1; i <= number; i++) {
        if (i % 15 == 0) {
            printf ("FizzBuzz");
        } else if (i % 3 == 0) {
            printf ("Fizz");
        } else if (i % 5 == 0) {
            printf ("Buzz");
        } else {
            printf ("%d", i);
        }
        printf("\n");
    }
    
    return 0;
}
 

